#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in ivec3 hudData;
layout(location = 5) in vec2 hudUV;
layout(location = 6) flat in vec2 hudSize;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

#ifdef IS_GUI
const float PI = 3.14159265;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
    return vnoise(p) * 0.6 + vnoise(p * 2.1 + 3.1) * 0.3 + vnoise(p * 4.3 + 7.7) * 0.1;
}

vec4 fetch(ivec2 t) {
    vec4 c = texelFetch(Sampler0, t, 0);
    if (abs(c.r - 1.0 / 255.0) < 0.002 && abs(c.g - 2.0 / 255.0) < 0.002 && abs(c.b - 3.0 / 255.0) < 0.002) {
        return vec4(0.0);
    }
    c.rgb *= c.a;
    return c;
}

// 글자 그림을 부드럽게 읽는다. (글꼴 아틀라스는 최근접 필터)
vec4 glyph() {
    vec2 tsz = vec2(textureSize(Sampler0, 0));
    vec2 p = texCoord0 * tsz - 0.5;
    vec2 f = fract(p);
    ivec2 i = ivec2(floor(p));
    vec4 c = mix(mix(fetch(i), fetch(i + ivec2(1, 0)), f.x), mix(fetch(i + ivec2(0, 1)), fetch(i + ivec2(1, 1)), f.x), f.y);
    if (c.a > 0.001) {
        c.rgb /= c.a;
    }
    return c;
}

float frac16(ivec3 d) {
    return float(d.g * 256 + d.b) / 65535.0;
}

// 먹으로 그은 막대. 양끝이 붓끝처럼 갈라진다.
vec4 brushBar(vec2 uv, float fill, vec3 colA, vec3 colB, float seed, bool bg) {
    float px = uv.x, py = uv.y;
    float wob = (fbm(vec2(px * 22.0 + seed, seed * 3.0)) - 0.5) * 0.36;
    float top = 0.14 + wob;
    float bot = 0.86 + (fbm(vec2(px * 19.0 + seed + 9.0, seed)) - 0.5) * 0.36;
    float endL = smoothstep(0.0, 0.02 + (vnoise(vec2(py * 9.0, seed)) * 0.03), px);
    float endR = 1.0 - smoothstep(0.98 - vnoise(vec2(py * 9.0, seed + 4.0)) * 0.03, 1.0, px);
    float aa = fwidth(py) * 1.4 + 0.003;
    float body = smoothstep(top - aa, top + aa, py) * (1.0 - smoothstep(bot - aa, bot + aa, py)) * endL * endR;
    if (body <= 0.002) return vec4(0.0);
    float streak = fbm(vec2(px * 7.0 + seed, py * 26.0));
    vec3 ink = vec3(0.035, 0.035, 0.05) * (0.8 + streak * 0.6);
    vec4 res = bg ? vec4(ink, body * 0.74) : vec4(0.0);
    float edge = aa * 0.5 + fwidth(px);
    float inFill = 1.0 - smoothstep(fill - edge, fill + edge, px);
    if (inFill > 0.0) {
        float g = py;
        vec3 c = mix(colA, colB, smoothstep(0.2, 0.9, g));
        c *= 0.82 + streak * 0.42;
        // 채움 끝의 밝은 선
        float tip = smoothstep(fill - 0.018, fill - 0.002, px) * (1.0 - smoothstep(fill - 0.002, fill + 0.003, px));
        c = mix(c, vec3(1.0, 0.96, 0.88), tip * 0.8);
        res.rgb = mix(res.rgb, c, inFill);
        res.a = max(res.a, body * inFill);
    }
    return res;
}

// 가운데에서 양옆으로 차오르는 체세 막대
vec4 postureBar(vec2 uv, float fill, float seed) {
    float x = abs(uv.x - 0.5) * 2.0;
    float py = uv.y;
    float aa = fwidth(py) * 1.4 + 0.004;
    float thick = mix(0.5, 0.26, x);
    float body = (1.0 - smoothstep(thick - aa, thick + aa, abs(py - 0.5))) * (1.0 - smoothstep(0.97, 1.0, x));
    if (body <= 0.002) return vec4(0.0);
    vec4 res = vec4(0.03, 0.03, 0.04, body * 0.62);
    float inFill = 1.0 - smoothstep(fill - 0.006, fill + 0.006, x);
    if (inFill > 0.0) {
        vec3 c = mix(vec3(1.0, 0.86, 0.45), vec3(1.0, 0.36, 0.14), smoothstep(0.45, 1.0, fill));
        float tip = smoothstep(fill - 0.03, fill, x);
        c = mix(c, vec3(1.0), tip * 0.7);
        res.rgb = mix(res.rgb, c, inFill);
        res.a = max(res.a, body * inFill);
    }
    return res;
}

vec4 hudColor() {
    int id = hudData.r;
    int g = hudData.g, b = hudData.b;
    vec2 uv = hudUV;
    float now = GameTime * 24000.0;

    if (id == 0xE0 || id == 0xE4) {
        return brushBar(uv, frac16(hudData), vec3(0.95, 0.22, 0.16), vec3(0.62, 0.05, 0.07), 1.3, true);
    }
    if (id == 0xE1 || id == 0xE5) {
        vec4 c = brushBar(uv, frac16(hudData), vec3(1.0, 0.92, 0.72), vec3(1.0, 0.72, 0.5), 1.3, false);
        return c;
    }
    if (id == 0xE2) {
        return brushBar(uv, frac16(hudData), vec3(0.46, 0.78, 1.0), vec3(0.14, 0.42, 0.9), 4.1, true);
    }
    // 관전 막대: 왼쪽 사람은 왼끝에, 오른쪽 사람은 오른끝에 붙어 가운데부터 빈다.
    if (id == 0xD8 || id == 0xDB) {
        vec2 u = id == 0xDB ? vec2(1.0 - uv.x, uv.y) : uv;
        return brushBar(u, frac16(hudData), vec3(0.95, 0.22, 0.16), vec3(0.62, 0.05, 0.07), id == 0xDB ? 2.7 : 1.3, true);
    }
    if (id == 0xD9 || id == 0xDC) {
        vec2 u = id == 0xDC ? vec2(1.0 - uv.x, uv.y) : uv;
        return brushBar(u, frac16(hudData), vec3(1.0, 0.92, 0.72), vec3(1.0, 0.72, 0.5), id == 0xDC ? 2.7 : 1.3, false);
    }
    if (id == 0xDA || id == 0xDD) {
        return postureBar(uv, frac16(hudData), 2.0);
    }
    if (id == 0xE3 || id == 0xE6) {
        return postureBar(uv, frac16(hudData), 2.0);
    }
    if (id >= 0xE7 && id <= 0xEB) {
        // 초식 칸: 도장 위에 재사용 대기 부채꼴
        vec4 c = glyph();
        bool poor = (b & 128) != 0;
        float dur = float(b & 127) * 8.0;
        vec2 q = uv - 0.5;
        float r = length(q) * 2.0;
        if (dur > 0.0) {
            float age = mod(now - float(g), 256.0);
            // 256틱을 넘는 대기는 서버가 다시 보낸다.
            float frac = clamp(age / dur, 0.0, 1.0);
            float ang = atan(q.x, -q.y) / (2.0 * PI);
            if (ang < 0.0) ang += 1.0;
            float dark = step(frac, ang);
            c.rgb = mix(c.rgb, c.rgb * 0.2, dark * 0.9);
            c.rgb = mix(c.rgb, vec3(dot(c.rgb, vec3(0.3, 0.6, 0.1))), dark * 0.6);
        }
        if (poor) {
            c.rgb *= 0.4;
        }
        return c;
    }
    if (id == 0xEC) {
        // 절초: 게이지가 원을 따라 차오른다.
        vec4 c = glyph();
        float fill = float(g) / 255.0;
        vec2 q = uv - 0.5;
        float r = length(q) * 2.0;
        float ang = atan(q.x, -q.y) / (2.0 * PI);
        if (ang < 0.0) ang += 1.0;
        float ring = smoothstep(0.80, 0.84, r) * (1.0 - smoothstep(0.96, 1.0, r));
        vec3 rc = fill >= 1.0 ? vec3(1.0, 0.86, 0.4) * (0.8 + 0.3 * sin(now * 0.5)) : vec3(1.0, 0.72, 0.3);
        vec4 res = c;
        res.rgb *= fill >= 1.0 ? 1.0 : 0.45;
        if (ang <= fill) {
            res.rgb = mix(res.rgb, rc, ring);
            res.a = max(res.a, ring);
        }
        return res;
    }
    if (id == 0xDF) {
        // 중심 묘리: 쌓인 만큼 고리가 차고, 다 차면 빛난다.
        vec4 c = glyph();
        float fill = float(g) / 255.0;
        vec2 q = uv - 0.5;
        float r = length(q) * 2.0;
        float ang = atan(q.x, -q.y) / (2.0 * PI);
        if (ang < 0.0) ang += 1.0;
        float ring = smoothstep(0.84, 0.88, r) * (1.0 - smoothstep(0.98, 1.02, r));
        vec3 rc = b == 1 ? vec3(1.0, 0.94, 0.66) * (0.86 + 0.24 * sin(now * 0.6)) : vec3(0.82, 0.84, 0.94);
        vec4 res = c;
        res.rgb *= mix(0.68, 1.0, fill);
        if (ang <= fill) {
            res.rgb = mix(res.rgb, rc, ring);
            res.a = max(res.a, ring);
        }
        return res;
    }
    if (id == 0xED) {
        // 경공 칸 세 개
        float charges = float(g);
        float regen = float(b) / 255.0;
        float x = uv.x * 3.0;
        float i = floor(x);
        vec2 q = vec2(fract(x) - 0.5, uv.y - 0.5) * vec2(1.0, hudSize.y / (hudSize.x / 3.0));
        float d = abs(q.x) + abs(q.y) * 1.2;
        float shape = 1.0 - smoothstep(0.26, 0.31, d);
        vec3 c = vec3(0.2);
        if (i < charges) c = vec3(0.86, 0.95, 1.0);
        else if (i < charges + 1.0) c = mix(vec3(0.2), vec3(0.5, 0.7, 0.9), regen);
        return vec4(c, shape * 0.95);
    }
    if (id == 0xEE) {
        // 적중 표시: 네 갈래 사선
        float age = mod(now - float(g), 256.0);
        float life = 7.0;
        if (age > life) return vec4(0.0);
        vec2 q = abs(uv - 0.5) * 2.0;
        float diag = abs(q.x - q.y);
        float r = length(q);
        float line = (1.0 - smoothstep(0.03, 0.07, diag)) * smoothstep(0.34, 0.42, r) * (1.0 - smoothstep(0.86, 0.98, r));
        vec3 col = b == 1 ? vec3(1.0, 0.82, 0.3) : b == 2 ? vec3(1.0, 0.25, 0.2) : vec3(1.0);
        return vec4(col, line * (1.0 - age / life));
    }
    if (id == 0xEF) {
        // 흘리기 고리
        float age = mod(now - float(g), 256.0);
        float life = float(max(b & 127, 1));
        if (age > life) return vec4(0.0);
        vec2 q = (uv - 0.5) * 2.0;
        float r = length(q);
        float rad = mix(0.36, 0.92, age / life);
        float line = 1.0 - smoothstep(0.0, 0.025, abs(r - rad));
        return vec4(0.75, 1.0, 0.86, line * (1.0 - age / life));
    }
    if (id >= 0xF0 && id <= 0xF2) {
        vec4 c = glyph();
        float age = mod(now - float(g), 256.0);
        float life = float(max(b & 127, 1));
        float fade = 1.0 - smoothstep(life * 0.72, life, age);
        // 찍히는 순간 하얗게 번쩍인다.
        float hot = 1.0 - smoothstep(0.0, 3.0, age);
        c.rgb = mix(c.rgb, vec3(1.0), hot * 0.6);
        c.a *= fade;
        return c;
    }
    if (id >= 0xF3 && id <= 0xF6) {
        vec4 c = glyph();
        float age = mod(now - float(g), 256.0);
        float hot = 1.0 - smoothstep(0.0, 4.0, age);
        c.rgb = mix(c.rgb, vec3(1.0, 0.8, 0.4), hot * 0.7);
        return c;
    }
    if (id == 0xFA) {
        // 상대 쪽을 가리키는 꺾쇠
        float a = float(g) / 256.0 * 2.0 * PI;
        vec2 q = (uv - 0.5) * 2.0;
        vec2 dir = vec2(sin(a), -cos(a));
        float along = dot(q, dir);
        float side = abs(q.x * dir.y - q.y * dir.x);
        float v = along + side;
        float band = smoothstep(0.34, 0.40, v) * (1.0 - smoothstep(0.62, 0.68, v)) * (1.0 - smoothstep(0.62, 0.72, side));
        float pulse = 0.72 + 0.28 * sin(now * 0.55);
        return vec4(mix(vec3(1.0, 0.42, 0.26), vec3(1.0, 0.86, 0.66), band), band * pulse);
    }
    if (id == 0xFC) {
        // 이음매의 겹친 2픽셀은 옆 조각이 그린다.
        vec2 q = uv * 250.0;
        if (q.x < 2.0 || q.x >= 248.0 || q.y < 2.0 || q.y >= 248.0) return vec4(0.0);
        vec2 sheet = (vec2(float(g & 3), float(g >> 2)) + (q - 2.0) / 246.0) / vec2(4.0, 2.0);
        float age = mod(now - float(b), 256.0);
        // 먹이 번지듯 왼쪽부터 드러났다가 옅어진다.
        float front = age / 20.0 * 1.4 - sheet.x - (fbm(sheet * vec2(9.0, 5.0)) - 0.5) * 0.35;
        vec4 c = glyph();
        c.a *= smoothstep(0.0, 0.2, front) * (1.0 - smoothstep(58.0, 74.0, age));
        return c;
    }
    if (id == 0xFD) {
        // 관 제목 뒤의 먹 자국. 가운데가 짙고 양끝은 마른 붓처럼 갈라진다.
        float age = mod(now - float(b), 256.0);
        float life = float(g);
        float streak = fbm(vec2(uv.x * 4.0 + 7.0, uv.y * 30.0));
        float wob = (fbm(vec2(uv.x * 5.0, 2.0)) - 0.5) * 0.2;
        float body = 1.0 - smoothstep(0.24, 0.48, abs(uv.y - 0.5 + wob) + (streak - 0.5) * 0.22);
        float x = uv.x + (streak - 0.5) * 0.25;
        float ends = smoothstep(0.02, 0.26, x) * (1.0 - smoothstep(0.74, 0.98, x));
        float front = age / 6.0 * 1.4 - uv.x - (fbm(uv * vec2(9.0, 5.0)) - 0.5) * 0.35;
        return vec4(0.02, 0.02, 0.03, body * ends * smoothstep(0.0, 0.2, front) * (1.0 - smoothstep(life - 6.0, life, age)) * 0.8);
    }
    if (id == 0xF8) {
        vec4 c = glyph();
        float fill = float(b) / 255.0;
        c.rgb *= uv.y > (1.0 - fill) ? 1.0 : 0.35;
        return c;
    }
    return glyph();
}
#endif

void main() {
    #ifdef IS_GUI
    if (hudData.r != 0) {
        vec4 h = hudColor();
        h.a *= vertexColor.a;
        if (h.a < 0.004) {
            discard;
        }
        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, h.a);
        #else
        fragColor = calculateFinalColor(h);
        #endif
        return;
    }
    #endif

    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
