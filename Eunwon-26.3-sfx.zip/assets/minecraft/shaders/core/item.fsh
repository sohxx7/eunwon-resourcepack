#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

layout(location = 7) flat in int eFam;
layout(location = 8) flat in vec4 eData;
layout(location = 9) in vec2 eUV;
layout(location = 10) flat in vec4 eColA;
layout(location = 11) flat in vec4 eColB;
layout(location = 12) flat in vec4 eColC;
layout(location = 13) in vec3 eView;
layout(location = 14) flat in vec2 eHide;
layout(location = 15) in float eDepth;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

const float PI = 3.14159265;
const float TAU = 6.2831853;

float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + 17.7;
        a *= 0.5;
    }
    return v;
}
float aaBand(float x, float lo, float hi, float w) {
    return smoothstep(lo - w, lo + w, x) * (1.0 - smoothstep(hi - w, hi + w, x));
}

// 초승달 베기 궤적 (family 0). a=호 각도(6도 단위), b=두께
vec4 fxArc(vec2 uv, float p, float life, float a, float b) {
    float r = length(uv);
    float w = max(fwidth(r) * 1.1, 0.0005);
    float span = max(a, 1.0) * 6.0 * PI / 180.0;
    float ang = atan(uv.y, uv.x);
    if (ang < 0.0) ang += TAU;
    float s = ang / span;
    if (s > 1.0) {
        // 시작점 쪽 살짝 넘어간 부분을 음수로 다뤄 경계를 부드럽게 한다.
        s = (ang - TAU) / span;
    }
    float head = smoothstep(0.0, 0.36, p);
    float tail = clamp((p - 0.2) / 0.8, 0.0, 1.0);
    tail = tail * tail;
    float vis = smoothstep(tail - 0.02, tail + 0.14, s) * (1.0 - smoothstep(head - 0.015, head + 0.015, s));
    if (vis <= 0.001) return vec4(0.0);
    float rel = clamp((s - tail) / max(head - tail, 0.001), 0.0, 1.0);
    float taper = pow(max(sin(rel * PI), 0.0), 0.55);
    float fat = (0.005 + 0.0012 * b * b) * taper * (1.0 - p * 0.55);
    float outer = 0.965;
    float inner = outer - max(fat, 0.0008);
    float band = aaBand(r, inner, outer, w);
    // 안쪽으로 얇게 번지는 잔광이 칼바람의 부피를 만든다.
    float haze = smoothstep(inner - min(fat * 5.0, 0.16) - w, inner, r) * (1.0 - smoothstep(outer - w, outer + w, r));
    if (band <= 0.001 && haze <= 0.001) return vec4(0.0);
    float t = clamp((r - inner) / max(outer - inner, 0.001), 0.0, 1.0);
    float streak = 0.72 + 0.28 * vnoise(vec2(r * 46.0, ang * 1.5 + 3.0));
    vec3 col = mix(eColC.rgb, eColB.rgb, smoothstep(0.0, 0.55, t));
    col = mix(col, eColA.rgb, smoothstep(0.55, 0.96, t));
    float alpha = max(band * mix(0.25, 1.0, pow(t, 1.6)) * streak, haze * haze * 0.26);
    return vec4(col, alpha * vis * (1.0 - p * p * 0.6));
}

// 충격파 고리 (family 1). a=두께, b=형태
vec4 fxRing(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float e = 1.0 - pow(1.0 - clamp(p, 0.0, 1.0), 3.0);
    float rad = 0.08 + e * 0.88;
    float th = (a / 63.0 * 0.35 + 0.02) * (1.0 - p);
    float w = fwidth(r) * 1.2;
    float band = aaBand(r, rad - th, rad, max(w, 0.002));
    float t = clamp((r - (rad - th)) / max(th, 0.001), 0.0, 1.0);
    vec3 col = mix(eColC.rgb, eColA.rgb, t);
    float ang = atan(uv.y, uv.x);
    float crack = b > 0.5 ? 0.65 + 0.35 * vnoise(vec2(ang * 9.0, r * 18.0)) : 1.0;
    return vec4(col, band * crack * (1.0 - p * p) * mix(0.25, 1.0, t));
}

// 타격 별빛 (family 2). a=광선 수, b=난수 씨앗
vec4 fxBurst(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float ang = atan(uv.y, uv.x);
    float n = max(a, 4.0);
    float k = ang / TAU * n;
    float id = floor(k);
    float f = fract(k) - 0.5;
    float rnd = hash21(vec2(id, b + 3.1));
    float rayLen = (0.45 + 0.55 * rnd) * (1.0 - pow(1.0 - clamp(p * 1.6, 0.0, 1.0), 3.0));
    float start = clamp(p * 1.7 - 0.25, 0.0, 1.0) * rayLen;
    float width = (0.42 * (1.0 - r / max(rayLen, 0.001))) * (1.0 - p);
    float ray = (1.0 - smoothstep(width * 0.6, width + 0.03, abs(f))) * step(start, r) * (1.0 - smoothstep(rayLen - 0.02, rayLen, r));
    float core = (1.0 - smoothstep(0.0, 0.34 * (1.0 - p), r));
    float alpha = max(ray, core);
    vec3 col = mix(eColB.rgb, eColA.rgb, max(core, 1.0 - r / max(rayLen, 0.001)));
    return vec4(col, alpha * (1.0 - p * p * p));
}

// 부드러운 빛 덩어리 (family 3). a=선명도
vec4 fxGlow(vec2 uv, float p, float a) {
    float r = length(uv);
    float g = pow(max(1.0 - r, 0.0), 1.5 + a / 63.0 * 5.0);
    float env = smoothstep(0.0, 0.08, p) * (1.0 - smoothstep(0.35, 1.0, p));
    return vec4(mix(eColB.rgb, eColA.rgb, g), g * env);
}

// 진법/기운 문양 (family 4). a=회전 속도, b=바퀴살 수
vec4 fxSigil(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float w = max(fwidth(r), 0.002);
    float env = smoothstep(0.0, 0.12, p) * (1.0 - smoothstep(0.82, 1.0, p));
    float t = GameTime * 24000.0 / 20.0;
    float rot = t * (a / 63.0 * 2.4);
    float ang = atan(uv.y, uv.x);
    float ring1 = aaBand(r, 0.93, 0.965, w);
    float ring2 = aaBand(r, 0.78, 0.80, w);
    float ring3 = aaBand(r, 0.30, 0.32, w);
    float n = max(b, 3.0);
    float spokes = aaBand(abs(fract((ang + rot) / TAU * n) - 0.5), 0.0, 0.03, 0.01) * aaBand(r, 0.32, 0.78, w);
    float ticks = aaBand(abs(fract((ang - rot * 0.6) / TAU * 36.0) - 0.5), 0.0, 0.12, 0.03) * aaBand(r, 0.82, 0.90, w);
    float diamond = 0.0;
    vec2 q = mat2(cos(rot), -sin(rot), sin(rot), cos(rot)) * uv;
    float dm = abs(q.x) + abs(q.y);
    diamond = aaBand(dm, 0.70, 0.73, w);
    float m = max(max(max(ring1, ring2), max(ring3, spokes)), max(ticks, diamond));
    vec3 col = mix(eColB.rgb, eColA.rgb, m);
    float fill = (1.0 - smoothstep(0.0, 1.0, r)) * 0.16;
    return vec4(col, max(m, fill) * env);
}

// 빔 (family 5): uv.y가 길이 방향, uv.x가 폭 방향. a=굵기
vec4 fxBeam(vec2 uv, float p, float a) {
    float th = (a / 63.0 + 0.05) * (1.0 - p * p);
    float x = abs(uv.x);
    float y = uv.y * 0.5 + 0.5;
    float flow = vnoise(vec2(uv.x * 6.0, y * 8.0 - GameTime * 24000.0 * 0.6));
    float core = 1.0 - smoothstep(th * 0.25, th * 0.55, x);
    float glow = pow(max(1.0 - x / max(th * 1.6, 0.001), 0.0), 2.0);
    float ends = smoothstep(0.0, 0.04, y) * (1.0 - smoothstep(0.92, 1.0, y));
    float alpha = max(core, glow * (0.45 + 0.4 * flow)) * ends;
    vec3 col = mix(eColB.rgb, eColA.rgb, core);
    return vec4(col, alpha * (1.0 - p * 0.3));
}

// 날아가는 검기 (family 6). 초승달 전체가 보이고 뒤로 꼬리를 끈다.
vec4 fxWave(vec2 uv, float p, float a, float b) {
    // 호의 가운데가 쿼드 가운데에 오도록 원의 중심을 아래로 내린다.
    vec2 c = uv + vec2(0.0, 0.85);
    float r = length(c) / 1.15;
    float w = max(fwidth(r) * 1.2, 0.002);
    float span = max(a, 1.0) * 6.0 * PI / 180.0;
    float ang = atan(c.x, c.y);
    float s = abs(ang) / (span * 0.5);
    if (s > 1.0) return vec4(0.0);
    float taper = pow(1.0 - s * s, 0.6);
    float fat = (0.05 + b / 15.0 * 0.24) * taper;
    float outer = 0.96;
    float inner = outer - fat;
    float band = aaBand(r, inner, outer, w);
    float t = clamp((r - inner) / max(fat, 0.001), 0.0, 1.0);
    vec3 col = mix(eColC.rgb, eColB.rgb, smoothstep(0.0, 0.6, t));
    col = mix(col, eColA.rgb, smoothstep(0.6, 0.97, t));
    float env = smoothstep(0.0, 0.06, p) * (1.0 - smoothstep(0.86, 1.0, p));
    float streak = 0.75 + 0.25 * vnoise(vec2(r * 30.0 - GameTime * 24000.0 * 0.8, ang * 3.0));
    return vec4(col, band * env * streak * mix(0.2, 1.0, pow(t, 1.3)));
}

// 먹 번짐 (family 7). a=크기, b=씨앗
vec4 fxInk(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float n = fbm(uv * 3.2 + b * 7.3);
    float spread = 0.25 + 0.75 * (1.0 - pow(1.0 - clamp(p * 2.2, 0.0, 1.0), 3.0));
    float mask = 1.0 - smoothstep(spread - 0.12, spread, r + (n - 0.5) * 0.7);
    mask *= 1.0 - smoothstep(0.85, 1.0, r);
    float dissolve = smoothstep(p * 1.35 - 0.35, p * 1.35 - 0.2, n + (1.0 - r) * 0.25);
    vec3 col = mix(eColA.rgb, eColB.rgb, n);
    return vec4(col, mask * dissolve * (0.92 - p * 0.3));
}

// 불꽃·연기 (family 8): uv.y 위로 흐른다. a=밀도
vec4 fxFlame(vec2 uv, float p, float a, float b) {
    float t = GameTime * 24000.0 * 0.09;
    vec2 q = vec2(uv.x * 1.7, uv.y * 1.1 - t);
    float n = fbm(q * 2.3 + b);
    float h = 1.0 - (uv.y * 0.5 + 0.5);
    float shape = 1.0 - smoothstep(0.1, 0.92, length(vec2(uv.x * 1.2, uv.y * 0.8 + 0.1)));
    float m = smoothstep(0.32, 0.72, n * (0.45 + shape) + shape * 0.25);
    float env = smoothstep(0.0, 0.14, p) * (1.0 - smoothstep(0.6, 1.0, p));
    vec3 col = mix(eColC.rgb, eColB.rgb, smoothstep(0.1, 0.6, m * h + 0.2));
    col = mix(col, eColA.rgb, smoothstep(0.55, 1.0, m * h * 1.6));
    float edge = (1.0 - smoothstep(0.7, 1.0, abs(uv.x))) * (1.0 - smoothstep(0.75, 1.0, abs(uv.y)));
    return vec4(col, m * env * edge * (a / 63.0 * 0.6 + 0.4));
}

// 번개 (family 9): uv.y 길이 방향. a=굵기, b=씨앗
vec4 fxBolt(vec2 uv, float p, float a, float b) {
    float flick = step(0.25, fract(GameTime * 24000.0 * 0.5 + b * 0.37));
    float y = uv.y * 0.5 + 0.5;
    float seed = b + floor(GameTime * 24000.0 * 0.5);
    float path = (vnoise(vec2(y * 5.0, seed)) - 0.5) * 0.9 + (vnoise(vec2(y * 17.0, seed + 5.0)) - 0.5) * 0.35;
    path *= sin(y * PI);
    float d = abs(uv.x - path);
    float th = (a / 63.0 * 0.05 + 0.012) * (1.0 - p * 0.7);
    float core = 1.0 - smoothstep(th * 0.6, th, d);
    float glow = pow(max(1.0 - d / (th * 7.0), 0.0), 2.0) * 0.55;
    float alpha = max(core, glow) * (0.55 + 0.45 * flick) * (1.0 - p * p);
    return vec4(mix(eColB.rgb, eColA.rgb, core), alpha);
}

// 태극 (family 10). a=회전 속도
vec4 fxTaiji(vec2 uv, float p, float a) {
    float env = smoothstep(0.0, 0.14, p) * (1.0 - smoothstep(0.84, 1.0, p));
    float rot = GameTime * 24000.0 / 20.0 * (a / 63.0 * 6.0);
    vec2 q = mat2(cos(rot), -sin(rot), sin(rot), cos(rot)) * uv;
    float r = length(q);
    float w = max(fwidth(r) * 1.2, 0.002);
    float outer = 1.0 - smoothstep(0.92 - w, 0.92 + w, r);
    float rim = aaBand(r, 0.92, 0.97, w);
    float side = q.x + (length(q - vec2(0.0, 0.46)) < 0.46 ? -10.0 : 0.0) + (length(q + vec2(0.0, 0.46)) < 0.46 ? 10.0 : 0.0);
    float yang = smoothstep(-w, w, side);
    float dotA = 1.0 - smoothstep(0.12 - w, 0.12 + w, length(q - vec2(0.0, 0.46)));
    float dotB = 1.0 - smoothstep(0.12 - w, 0.12 + w, length(q + vec2(0.0, 0.46)));
    yang = mix(yang, 1.0, dotA);
    yang = mix(yang, 0.0, dotB);
    vec3 col = mix(eColB.rgb, eColA.rgb, yang);
    col = mix(col, eColA.rgb, rim);
    return vec4(col, max(outer * 0.82, rim) * env);
}

// 텍스처 스프라이트 (family 11): 다음 줄부터 실제 그림이 있는 아틀라스 칸을 eColC로 가리키지 않고 texCoord0를 직접 쓴다.
vec4 fxPetal(vec2 uv, float p, float a, float b) {
    // 꽃잎 하나: 끝이 뾰족한 타원
    float c = cos(b), s = sin(b);
    vec2 q = mat2(c, -s, s, c) * uv;
    float shape = 1.0 - smoothstep(0.82, 0.96, length(vec2(q.x * 1.9, q.y)) + q.y * q.y * 0.22);
    float notch = smoothstep(0.0, 0.08, length(q - vec2(0.0, 0.92)));
    float vein = 0.8 + 0.2 * smoothstep(0.0, 0.5, abs(q.x));
    vec3 col = mix(eColB.rgb, eColA.rgb, (1.0 - abs(q.y)) * vein * 0.45);
    float near = smoothstep(1.5, 4.5, length(eView));
    return vec4(col, shape * notch * near * smoothstep(0.0, 0.08, p) * (1.0 - smoothstep(0.75, 1.0, p)));
}

// 거대한 장법 (family 12): 손바닥 윤곽
vec4 fxPalm(vec2 uv, float p, float a) {
    vec2 q = uv * vec2(1.25, 1.1) + vec2(0.0, 0.18);
    float palm = length(max(abs(q) - vec2(0.42, 0.38), 0.0)) - 0.12;
    float d = palm;
    for (int i = 0; i < 4; i++) {
        float fx = -0.42 + float(i) * 0.28;
        float len = i == 0 ? 0.42 : i == 3 ? 0.40 : 0.60;
        vec2 f = q - vec2(fx, 0.5 + len * 0.5);
        d = min(d, length(max(abs(f) - vec2(0.075, len * 0.5), 0.0)) - 0.055);
    }
    vec2 th = mat2(0.82, -0.57, 0.57, 0.82) * (q - vec2(0.62, 0.05));
    d = min(d, length(max(abs(th) - vec2(0.08, 0.28), 0.0)) - 0.06);
    float w = max(fwidth(d) * 1.2, 0.003);
    float fill = 1.0 - smoothstep(-w, w, d);
    float rim = aaBand(d, -0.05, 0.0, w);
    float glow = pow(max(1.0 - max(d, 0.0) * 3.2, 0.0), 2.0) * 0.5;
    float env = smoothstep(0.0, 0.1, p) * (1.0 - smoothstep(0.72, 1.0, p));
    float flow = 0.72 + 0.28 * fbm(uv * 4.0 + vec2(0.0, -GameTime * 24000.0 * 0.08));
    vec3 col = mix(eColB.rgb, eColA.rgb, max(rim, fill * flow * 0.6));
    return vec4(col, max(max(fill * 0.72 * flow, rim), glow) * env);
}

// 튀는 방울 (eFam 30). a=개수, b=씨앗. 피와 불똥을 같이 쓴다.
vec4 fxSpray(vec2 uv, float p, float a, float b) {
    float best = 0.0;
    int n = int(clamp(a, 1.0, 26.0));
    float e = 1.0 - pow(1.0 - p, 2.4);
    for (int i = 0; i < n; i++) {
        float fi = float(i) + b * 3.7;
        float h1 = hash21(vec2(fi, 1.3)), h2 = hash21(vec2(fi, 7.9)), h3 = hash21(vec2(fi, 13.1));
        float ang = h1 * TAU;
        float sp = 0.22 + h2 * 0.68;
        vec2 d0 = vec2(cos(ang), sin(ang));
        float fall = 0.32 + h3 * 0.3;
        vec2 c = d0 * sp * e - vec2(0.0, p * p * fall);
        vec2 vel = d0 * sp * 2.4 * pow(1.0 - p, 1.4) - vec2(0.0, 2.0 * p * fall);
        float speed = length(vel);
        vec2 nv = vel / max(speed, 0.001);
        vec2 q = uv - c;
        float along = dot(q, nv), across = q.x * nv.y - q.y * nv.x;
        float size = (0.008 + h3 * h3 * 0.026) * (1.0 - p * 0.65);
        float m = 1.0 - smoothstep(size * 0.55, size, length(vec2(along / (1.0 + speed * 1.7), across)));
        best = max(best, m);
    }
    return vec4(mix(eColB.rgb, eColA.rgb, best), best * (1.0 - smoothstep(0.7, 1.0, p)));
}

// 칼자국 번쩍임 (eFam 31). a=줄 수, b=씨앗. 두 줄이면 X자가 된다.
vec4 fxCut(vec2 uv, float p, float a, float b) {
    float best = 0.0;
    int n = int(clamp(a, 1.0, 6.0));
    float base = hash21(vec2(b, 2.7)) * PI;
    float grow = 1.0 - pow(1.0 - min(p * 2.6, 1.0), 3.0);
    float thin = pow(1.0 - p, 1.5);
    for (int i = 0; i < n; i++) {
        float h = hash21(vec2(b + float(i), 5.1));
        float ang = base + float(i) * PI / float(n) + (h - 0.5) * 0.5;
        float c = cos(ang), s = sin(ang);
        vec2 q = mat2(c, -s, s, c) * uv;
        float len = (0.3 + 0.68 * grow) * (0.72 + 0.28 * h);
        float wid = 0.075 * thin + 0.002;
        float d = abs(q.x) / len + abs(q.y) / wid;
        best = max(best, 1.0 - smoothstep(0.62, 1.0, d));
    }
    vec3 col = mix(eColB.rgb, eColA.rgb, smoothstep(0.15, 0.7, best));
    return vec4(col, best * (1.0 - p * p));
}

// 흙먼지 (eFam 32). a=짙기, b=씨앗
vec4 fxPuff(vec2 uv, float p, float a, float b) {
    float e = 1.0 - pow(1.0 - p, 2.5);
    vec2 q = uv / (0.35 + 0.65 * e);
    float r = length(q);
    float n = fbm(q * 2.4 + b * 5.3 + vec2(0.0, p * 1.2));
    float m = 1.0 - smoothstep(0.25, 1.0, r + (n - 0.5) * 0.9);
    vec3 col = mix(eColB.rgb, eColA.rgb, n);
    return vec4(col, m * (a / 63.0 * 0.7 + 0.1) * (1.0 - smoothstep(0.25, 1.0, p)));
}

// 매화 한 송이 (eFam 35). b=씨앗. 피어났다가 잎이 흩어진다.
vec4 fxBlossom(vec2 uv, float p, float b) {
    float grow = 1.0 - pow(1.0 - clamp(p * 2.6, 0.0, 1.0), 3.0);
    float rot = b * 0.7 + p * 0.8;
    float c = cos(rot), s = sin(rot);
    vec2 q = mat2(c, -s, s, c) * uv / max(0.2 + grow * 0.8, 0.01);
    float r = length(q);
    float ang = atan(q.y, q.x);
    // 다섯 잎: 잎 사이가 움푹 들어간다.
    float lobe = abs(cos(ang * 2.5));
    float edge = 0.56 + 0.38 * pow(lobe, 0.55);
    float w = max(fwidth(r) * 1.2, 0.004);
    float body = 1.0 - smoothstep(edge - w, edge + w, r);
    // 지면서 바깥부터 흩어진다.
    float n = vnoise(q * 5.5 + b * 3.1);
    float dissolve = 1.0 - smoothstep(0.55, 1.0, p + (r - 0.45) * 0.55 + (n - 0.5) * 0.35);
    float heart = 1.0 - smoothstep(0.0, 0.3, r);
    float vein = 0.86 + 0.14 * smoothstep(0.0, 0.6, lobe);
    // 블룸은 0.9부터 번진다. 흰 꽃잎이 뭉개지지 않게 누른다.
    vec3 petal = mix(eColB.rgb, eColA.rgb, 0.5);
    vec3 col = mix(eColB.rgb, petal, smoothstep(0.12, 0.7, r)) * vein * 0.84;
    col = mix(col, eColC.rgb, heart * 0.75);
    // 수술
    float rays = (1.0 - smoothstep(0.0, 0.06, abs(fract((ang + 0.31) / TAU * 10.0) - 0.5))) * aaBand(r, 0.1, 0.34, w);
    float tips = (1.0 - smoothstep(0.0, 0.18, abs(fract((ang + 0.31) / TAU * 10.0) - 0.5))) * aaBand(r, 0.32, 0.38, w);
    col = mix(col, vec3(1.0, 0.9, 0.55), max(rays * 0.8, tips));
    return vec4(col, max(body * 0.94, tips) * dissolve * smoothstep(0.0, 0.05, p));
}

// 얼음꽃 (eFam 36). 여섯 갈래로 맺혔다가 깨진다.
vec4 fxFlake(vec2 uv, float p, float b) {
    float grow = 1.0 - pow(1.0 - clamp(p * 3.2, 0.0, 1.0), 3.0);
    float rot = b * 0.5 + p * 0.5;
    float c = cos(rot), s = sin(rot);
    vec2 q = mat2(c, -s, s, c) * uv / max(0.25 + grow * 0.75, 0.01);
    float r = length(q);
    float ang = mod(atan(q.y, q.x), PI / 3.0) - PI / 6.0;
    vec2 f = vec2(cos(ang), abs(sin(ang))) * r;
    float w = max(fwidth(r) * 1.2, 0.004);
    float arm = (1.0 - smoothstep(0.016, 0.03 + w, f.y)) * (1.0 - smoothstep(0.86, 0.92, f.x));
    // 줄기에서 비스듬히 뻗는 가지
    float br = 0.0;
    for (int i = 0; i < 3; i++) {
        float x0 = 0.28 + float(i) * 0.2;
        vec2 g = f - vec2(x0, 0.0);
        float d = abs(g.y - g.x * 1.0) ;
        br = max(br, (1.0 - smoothstep(0.012, 0.026 + w, d)) * step(0.0, g.x) * (1.0 - smoothstep(0.2 - float(i) * 0.04, 0.24 - float(i) * 0.04, g.x)));
    }
    float hex = aaBand(max(abs(q.x) * 0.866 + abs(q.y) * 0.5, abs(q.y)), 0.2, 0.225, w);
    float m = max(max(arm, br), hex);
    float glow = pow(max(1.0 - r, 0.0), 2.4) * 0.5;
    float n = vnoise(q * 7.0 + b);
    float shatter = 1.0 - smoothstep(0.62, 1.0, p + (n - 0.5) * 0.3);
    vec3 col = mix(eColB.rgb, eColA.rgb, m);
    return vec4(col, max(m, glow) * shatter * smoothstep(0.0, 0.05, p));
}

// 소용돌이 (eFam 37). a=도는 빠르기, b=팔 수. 안으로 빨려 든다.
vec4 fxSpiral(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float ang = atan(uv.y, uv.x);
    float t = GameTime * 24000.0 / 20.0 * (a / 63.0 * 3.2 + 0.2);
    float arms = max(b, 2.0);
    float s = fract(ang / TAU * arms + log(max(r, 0.02)) * 1.7 + t * arms);
    float band = smoothstep(0.0, 0.22, s) * (1.0 - smoothstep(0.34, 0.66, s));
    float edge = (1.0 - smoothstep(0.74, 1.0, r)) * smoothstep(0.0, 0.1, r);
    float env = smoothstep(0.0, 0.1, p) * (1.0 - smoothstep(0.82, 1.0, p));
    float n = 0.72 + 0.28 * vnoise(vec2(r * 14.0 - t * 5.0, ang * 2.0));
    vec3 col = mix(eColC.rgb, eColB.rgb, band);
    col = mix(col, eColA.rgb, band * band * (1.0 - r));
    return vec4(col, band * edge * env * n * 0.9);
}

// 땅이 갈라진다 (eFam 38). a=갈래 수, b=씨앗
vec4 fxCrack(vec2 uv, float p, float a, float b) {
    float r = length(uv);
    float ang = atan(uv.y, uv.x);
    float n = max(a, 5.0);
    float grow = 1.0 - pow(1.0 - clamp(p * 5.0, 0.0, 1.0), 3.0);
    float wob = (vnoise(vec2(r * 7.0, b * 3.7)) - 0.5) * 0.9 + (vnoise(vec2(r * 19.0, b * 7.1)) - 0.5) * 0.36;
    float k = ang / TAU * n + wob * smoothstep(0.0, 0.3, r) * 0.42;
    float id = floor(k);
    float f = abs(fract(k) - 0.5);
    float rnd = hash21(vec2(id, b + 2.3));
    float len = (0.45 + 0.55 * rnd) * grow;
    float w = max(fwidth(k) * 1.2, 0.006);
    float th = 0.03 * (1.0 - clamp(r / max(len, 0.001), 0.0, 1.0)) + 0.003;
    float line = (1.0 - smoothstep(th, th + w, f)) * (1.0 - smoothstep(len - 0.02, len, r));
    float hot = 1.0 - smoothstep(0.0, 0.5, p);
    vec3 col = mix(vec3(0.05, 0.04, 0.05), eColA.rgb, hot * 0.9 + 0.1 * (1.0 - r));
    vec3 glowCol = mix(col, eColB.rgb, hot * 0.5);
    return vec4(glowCol, line * (1.0 - smoothstep(0.55, 1.0, p)));
}

// 저녁 하늘의 근사. 바닥에 비칠 때만 쓴다. 파노라마처럼 해는 +z 쪽에 낮게 떠 있다.
vec3 duskSky(vec3 d) {
    float y = max(d.y, 0.0);
    vec3 col = mix(vec3(1.0, 0.66, 0.46), vec3(0.93, 0.50, 0.72), smoothstep(0.0, 0.2, y));
    col = mix(col, vec3(0.42, 0.44, 0.90), smoothstep(0.16, 0.62, y));
    float s = max(dot(d, normalize(vec3(0.0, 0.13, 1.0))), 0.0);
    col += vec3(1.0, 0.82, 0.58) * (pow(s, 18.0) * 0.5 + pow(s, 160.0) * 1.4);
    float az = atan(d.x, d.z);
    float ridge = 0.05 + 0.035 * sin(az * 7.0 + 1.3) + 0.018 * sin(az * 19.0);
    return mix(vec3(0.11, 0.11, 0.27), col, smoothstep(ridge - 0.015, ridge + 0.015, y));
}

// 바닥 그림의 n번째 줄인 그림을 부드럽게 읽는다. 1번부터는 원본 아래쪽에 왼쪽부터 이어 붙어 있다.
vec3 floorLevel(vec2 local, int n) {
    float s = 1.0 / float(1 << n);
    float size = 2048.0 * s;
    ivec2 o = ivec2(eData.xy) + (n > 0 ? ivec2(int(2048.0 - 4096.0 * s), 2048) : ivec2(0));
    vec2 q = clamp(local * s - 0.5, vec2(0.0), vec2(size - 1.001));
    ivec2 i = ivec2(floor(q));
    vec2 f = q - vec2(i);
    vec3 a = texelFetch(Sampler0, o + i, 0).rgb, b = texelFetch(Sampler0, o + i + ivec2(1, 0), 0).rgb;
    vec3 c = texelFetch(Sampler0, o + i + ivec2(0, 1), 0).rgb, d = texelFetch(Sampler0, o + i + ivec2(1, 1), 0).rgb;
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 비무대 바닥 (eFam 33): 그려 둔 판석에 젖은 돌 같은 윤기로 노을을 비춘다.
vec4 fxFloor() {
    vec2 local = texCoord0 * vec2(textureSize(Sampler0, 0)) - eData.xy;
    if (distance(local, vec2(1024.0)) > 1003.5) return vec4(0.0);
    float foot = max(length(dFdx(local)), length(dFdy(local)));
    float lod = clamp(log2(max(foot, 1.0)), 0.0, 3.99);
    int n = int(lod);
    vec3 albedo = mix(floorLevel(local, n), floorLevel(local, n + 1), fract(lod));
    vec2 w = local / 29.26;
    float near = 1.0 / max(foot, 1.0);
    float grain = vnoise(w * 16.0) * 0.6 + vnoise(w * 47.0) * 0.4;
    albedo *= 1.0 + (grain - 0.5) * 0.16 * near;

    float lum = dot(albedo, vec3(0.3, 0.55, 0.15));
    // 가까이에서만 돌 결을 윤기에 태운다. 멀면 지글거리기만 한다.
    float lx = 0.0, lz = 0.0;
    if (near > 0.2) {
        float e = max(foot, 1.0);
        lx = dot(floorLevel(local + vec2(e, 0.0), n) - floorLevel(local - vec2(e, 0.0), n), vec3(0.33));
        lz = dot(floorLevel(local + vec2(0.0, e), n) - floorLevel(local - vec2(0.0, e), n), vec3(0.33));
    }
    float wave = vnoise(w * 3.1) - 0.5, wave2 = vnoise(w.yx * 3.3 + 9.0) - 0.5;
    // 비스듬히 보는 먼 바닥은 작은 기울기에도 반사가 크게 흔들려 물결처럼 보인다. 멀수록 줄인다.
    float ripple = 0.05 * mix(0.15, 1.0, near);
    vec3 N = normalize(vec3(-lx * 2.4 * near + wave * ripple, 1.0, -lz * 2.4 * near + wave2 * ripple));
    vec3 V = normalize(eView);
    vec3 R = reflect(V, N);
    R.y = abs(R.y);
    float ndv = clamp(dot(-V, N), 0.0, 1.0);
    float fresnel = 0.035 + 0.965 * pow(1.0 - ndv, 5.0);
    // 멀어질수록 이음매가 윤기를 끊지 않게 해서 지평선 쪽이 지글거리지 않는다.
    float gloss = mix(0.72, smoothstep(0.05, 0.22, lum), near) * (0.6 + 0.4 * vnoise(w * 0.7 + 5.0));
    vec3 col = mix(albedo * 1.14, duskSky(normalize(R)) * 0.92, min(fresnel * gloss, 0.5));
    return vec4(col, 1.0);
}

// 발밑 그림자 (eFam 34): 동그란 그늘과 해 반대쪽으로 끌리는 자락. 로컬 +y가 세계 -z다.
vec4 fxShadow(vec2 uv) {
    float blob = exp(-dot(uv, uv) * 42.0);
    float len = clamp(uv.y, 0.0, 1.0);
    float streak = exp(-uv.x * uv.x * 150.0) * (1.0 - smoothstep(0.0, 0.92, len)) * step(0.0, uv.y);
    return vec4(0.02, 0.02, 0.07, max(blob * 0.62, streak * 0.3));
}

// 운해 (family 13): 수명과 상관없이 계속 보이는 구름바다. a=층 번호
vec4 fxCloudSea(vec2 uv, float a) {
    float r = length(uv);
    float t = GameTime * 24000.0 * 0.0016;
    vec2 q = uv * (a > 0.5 ? 26.0 : 18.0);
    float n = fbm(q + vec2(t, t * 0.6) + a * 7.0);
    float n2 = fbm(q * 2.3 - vec2(t * 1.4, t * 0.4) + 3.0);
    float m = smoothstep(0.34, 0.68, n * 0.7 + n2 * 0.34);
    float edge = 1.0 - smoothstep(0.55, 1.0, r);
    vec3 col = mix(eColC.rgb, eColB.rgb, smoothstep(0.36, 0.7, n));
    col = mix(col, eColA.rgb, smoothstep(0.55, 0.85, n2 * 0.6 + n * 0.5));
    return vec4(col, m * edge * (a > 0.5 ? 0.62 : 0.9));
}

vec4 runFx(int fam) {
    if (fam == 23) return fxCloudSea(eUV, eData.z);
    if (fam == 33) return fxFloor();
    if (fam == 34) return fxShadow(eUV);
    if (fam == 24) {
        // 등불빛: 수명 없이 계속 일렁인다.
        float r = length(eUV);
        float g = pow(max(1.0 - r, 0.0), 2.6);
        float t = GameTime * 24000.0;
        float flick = 0.86 + 0.14 * sin(t * 0.37) * sin(t * 0.91);
        return vec4(mix(eColB.rgb, eColA.rgb, g), g * 0.55 * flick);
    }
    float p = eData.x;
    if (p < 0.0 || p >= 1.0) return vec4(0.0);
    vec2 uv = eUV;
    if (fam == 10) return fxArc(uv, p, eData.y, eData.z, eData.w);
    if (fam == 11) return fxRing(uv, p, eData.z, eData.w);
    if (fam == 12) return fxBurst(uv, p, eData.z, eData.w);
    if (fam == 13) return fxGlow(uv, p, eData.z);
    if (fam == 14) return fxSigil(uv, p, eData.z, eData.w);
    if (fam == 15) return fxBeam(uv, p, eData.z);
    if (fam == 16) return fxWave(uv, p, eData.z, eData.w);
    if (fam == 17) return fxInk(uv, p, eData.z, eData.w);
    if (fam == 18) return fxFlame(uv, p, eData.z, eData.w);
    if (fam == 19) return fxBolt(uv, p, eData.z, eData.w);
    if (fam == 20) return fxTaiji(uv, p, eData.z);
    if (fam == 21) return fxPetal(uv, p, eData.z, eData.w);
    if (fam == 22) return fxPalm(uv, p, eData.z);
    if (fam == 25) return fxArc(uv, p, eData.y, eData.z, eData.w);
    if (fam == 30) return fxSpray(uv, p, eData.z, eData.w);
    if (fam == 31) return fxCut(uv, p, eData.z, eData.w);
    if (fam == 32) return fxPuff(uv, p, eData.z, eData.w);
    if (fam == 35) return fxBlossom(uv, p, eData.w);
    if (fam == 36) return fxFlake(uv, p, eData.w);
    if (fam == 37) return fxSpiral(uv, p, eData.z, eData.w);
    if (fam == 38) return fxCrack(uv, p, eData.z, eData.w);
    return vec4(0.0);
}

// 무기 (eFam 5): gen_weapons.py의 그림 한 장을 읽는다. 왼쪽 절반은 (법선 x, 덮임, 법선 y), 오른쪽 절반은 (밝기, 광택, 발광)이다.
const float WEAPON_AUX = 1024.0;

// 아틀라스는 가장 가까운 칸만 읽는다. 가까이에서 윤곽과 법선이 계단지지 않게 네 칸을 섞는다.
vec3 atlasLinear(vec2 tc) {
    vec2 q = tc - 0.5;
    ivec2 i = ivec2(floor(q));
    vec2 f = q - vec2(i);
    vec3 a = texelFetch(Sampler0, i, 0).rgb, b = texelFetch(Sampler0, i + ivec2(1, 0), 0).rgb;
    vec3 c = texelFetch(Sampler0, i + ivec2(0, 1), 0).rgb, d = texelFetch(Sampler0, i + ivec2(1, 1), 0).rgb;
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// 쇠에 비치는 세상: 위는 저녁 하늘, 아래는 노을이 깔린 돌바닥이다.
vec3 mirrorWorld(vec3 d) {
    if (d.y >= 0.0) {
        return duskSky(d);
    }
    float y = -d.y;
    float s = max(dot(normalize(vec3(d.x, 0.0, d.z) + vec3(1e-4)), vec3(0.0, 0.0, 1.0)), 0.0);
    vec3 ground = mix(vec3(0.24, 0.19, 0.29), vec3(0.44, 0.30, 0.31), s * s);
    return mix(vec3(0.11, 0.11, 0.27), ground, smoothstep(0.0, 0.14, y));
}

vec4 shadeWeapon() {
    vec2 size = vec2(textureSize(Sampler0, 0));
    vec2 tc = texCoord0 * size;
    vec2 dx = dFdx(tc), dy = dFdy(tc);
    vec3 px = dFdx(eView), py = dFdy(eView);
    float foot = max(length(dx), length(dy));
    vec3 a, b;
    if (foot > 1.25) {
        // 멀면 줄인 그림을 읽어 지글거리지 않게 한다.
        float lod = log2(foot);
        a = textureLod(Sampler0, texCoord0, lod).rgb;
        b = textureLod(Sampler0, texCoord0 + vec2(WEAPON_AUX, 0.0) / size, lod).rgb;
    } else {
        a = atlasLinear(tc);
        b = atlasLinear(tc + vec2(WEAPON_AUX, 0.0));
    }
    if (a.g < 0.5) {
        return vec4(0.0);
    }

    // 그림의 가로세로가 세상에서 어느 쪽인지 화면 변화량으로 구해 법선을 기울인다.
    vec3 geo = normalize(eColB.xyz);
    vec3 N = geo;
    float det = dx.x * dy.y - dx.y * dy.x;
    if (abs(det) > 1e-9) {
        vec3 pu = (px * dy.y - py * dx.y) / det;
        vec3 pv = (py * dx.x - px * dy.x) / det;
        vec3 tu = normalize(pu - geo * dot(pu, geo));
        vec3 tv = normalize(pv - geo * dot(pv, geo));
        vec2 n = (a.rb * 255.0 - 128.0) / 127.0;
        N = normalize(geo * sqrt(max(1.0 - dot(n, n), 0.0)) + tu * n.x + tv * n.y);
    }

    vec3 V = normalize(eView);
    vec3 R = reflect(V, N);
    float fresnel = pow(1.0 - clamp(dot(-V, N), 0.0, 1.0), 5.0);
    vec3 albedo = eColA.rgb * b.r * 2.0;
    int metal = int(eData.x + 0.5);

    vec3 diffuse;
    if (eData.z > 0.5) {
        // 1인칭은 고개를 돌려도 밝기가 변하지 않도록 시야 기준으로 빛을 준다. 팔과 같은 빛이다.
        vec3 vn = mat3(ModelViewMat) * N;
        float light = max(dot(normalize(vec3(0.25, 0.8, 0.55)), vn), 0.0) + max(dot(normalize(vec3(-0.6, 0.25, 0.5)), vn), 0.0);
        diffuse = vec3(min(light * 0.6 + 0.4, 1.0) * 0.9);
    } else {
        float key = max(dot(N, normalize(vec3(0.0, 0.3, 1.0))), 0.0);
        vec3 light = mix(vec3(0.40, 0.35, 0.52), vec3(0.70, 0.66, 0.86), N.y * 0.5 + 0.5) + vec3(0.72, 0.44, 0.24) * key;
        diffuse = min(light, vec3(0.98, 0.90, 0.90));
    }

    vec3 col;
    if (metal == 3) {
        // 닦은 쇠: 세상이 비치되 제 빛을 잃지 않는다. 하늘색을 그대로 받으면 유리처럼 보인다.
        vec3 env = mirrorWorld(R);
        env = mix(vec3(dot(env, vec3(0.3, 0.55, 0.15))), env, 0.42);
        col = albedo * (env * 0.72 + diffuse * 0.32);
    } else if (metal == 2) {
        // 금붙이: 반사가 조금 뭉개지고 제 색이 진하다.
        vec3 side = normalize(cross(N, vec3(0.31, 0.87, 0.38)));
        vec3 env = (mirrorWorld(R) + mirrorWorld(normalize(R + side * 0.3)) + mirrorWorld(normalize(R - side * 0.3))) / 3.0;
        col = albedo * (env * 0.72 + diffuse * 0.4);
    } else {
        // 옻칠과 옥은 겉에 윤이 돌고, 천과 가죽은 비스듬할 때만 살짝 빛난다.
        float sheen = metal == 1 ? 0.05 + 0.7 * fresnel : 0.015 + 0.16 * fresnel;
        col = albedo * diffuse + mirrorWorld(R) * sheen;
    }
    col += eColA.rgb * (eData.y * 0.8 + b.b * 1.5);
    return vec4(col, 1.0);
}

float bayer4(vec2 p) {
    const float m[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    ivec2 i = ivec2(mod(p, 4.0));
    return (m[i.x + i.y * 4] + 0.5) / 16.0;
}

void main() {
    if ((eHide.x > 0.0 && length(eView) < eHide.x) || (eHide.y > 0.0 && eDepth > eHide.y)) {
        discard;
    }
    if (eHide.x < 0.0 && smoothstep(-eHide.x * 0.4, -eHide.x, length(eView)) < bayer4(gl_FragCoord.xy)) {
        discard;
    }
    vec4 color;
    if (eFam == 100) {
        // 데이터 픽셀은 그대로 기록한다.
        #ifndef OIT_ALPHA_ONLY
        fragColor = vec4(eColA.rgb, 1.0);
        #endif
        return;
    } else if (eFam == 90) {
        // 잔상: 얼굴 쪽 면이 더 진하고 시간이 갈수록 사라진다.
        float p = eData.x;
        if (p >= 1.0) {
            discard;
        }
        vec3 tint = eColA.rgb;
        color = vec4(tint, (1.0 - p) * (1.0 - p) * 0.62);
    } else if (eFam == 5) {
        color = shadeWeapon();
        if (color.a < 0.5) {
            discard;
        }
    } else if (eFam >= 10) {
        color = runFx(eFam);
        if (eFam == 12 || eFam == 13 || eFam == 17 || eFam == 18 || eFam == 32 || eFam == 35 || eFam == 36) {
            // 빛무리, 먹, 불길, 흙먼지는 넓은 판이라 카메라가 그 안에 들어가면 화면을 통째로 덮는다. 가까울수록 옅게 한다.
            color.a *= 0.04 + 0.96 * smoothstep(0.7, 3.4, length(eView));
        }
        if (color.a < 0.004) {
            discard;
        }
    } else {
        color = texture(Sampler0, texCoord0);
        #ifdef ALPHA_CUTOUT
        if (color.a < ALPHA_CUTOUT) {
            discard;
        }
        #endif

        color *= vertexColor * ColorModulator;

        #ifdef GLINT
        color.a = max(color.a, GlintAlpha);
        #endif
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
