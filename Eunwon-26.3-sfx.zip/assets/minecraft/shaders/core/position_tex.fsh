#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec3 skyRay;
layout(location = 2) flat in int skyMode;
layout(location = 3) flat in vec2 skyCorner;
layout(location = 4) flat in vec2 skyUv;

layout(location = 0) out vec4 fragColor;

const float PI = 3.14159265;
// 파노라마 스프라이트 크기(픽셀). tools/gen_sky.py와 같아야 한다.
const vec2 PANO = vec2(4096.0, 2048.0);

vec3 pano(ivec2 origin, vec2 p) {
    // 아틀라스는 최근접 필터라 직접 쌍선형으로 읽는다.
    vec2 q = p - 0.5;
    vec2 f = fract(q);
    ivec2 i0 = ivec2(floor(q));
    int w = int(PANO.x), h = int(PANO.y);
    int x0 = (i0.x + w) % w, x1 = (i0.x + 1 + w) % w;
    int y0 = clamp(i0.y, 0, h - 1), y1 = clamp(i0.y + 1, 0, h - 1);
    vec3 c00 = texelFetch(Sampler0, origin + ivec2(x0, y0), 0).rgb;
    vec3 c10 = texelFetch(Sampler0, origin + ivec2(x1, y0), 0).rgb;
    vec3 c01 = texelFetch(Sampler0, origin + ivec2(x0, y1), 0).rgb;
    vec3 c11 = texelFetch(Sampler0, origin + ivec2(x1, y1), 0).rgb;
    return mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
}

void main() {
    if (skyMode == 1) {
        vec3 d = normalize(skyRay);
        float lon = atan(d.z, d.x) / (2.0 * PI) + 0.5;
        float lat = asin(clamp(d.y, -1.0, 1.0)) / PI + 0.5;
        vec2 tsz = vec2(textureSize(Sampler0, 0));
        // 꼭짓점의 uv에서 스프라이트 크기만큼 빼면 왼쪽 위 원점이 나온다.
        ivec2 origin = ivec2(floor(skyUv * tsz - skyCorner * PANO + 0.5));
        vec2 p = vec2(lon, 1.0 - lat) * PANO;
        fragColor = vec4(pano(origin, p), 1.0);
        return;
    }
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
