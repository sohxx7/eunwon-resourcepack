#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 하늘은 파노라마가 그리므로 바닥색은 검게 둔다. (해는 더하기로 합성된다)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;

layout(location = 0) out vec4 fragColor;

void main() {
    fragColor = vec4(0.0, 0.0, 0.0, 1.0);
}
