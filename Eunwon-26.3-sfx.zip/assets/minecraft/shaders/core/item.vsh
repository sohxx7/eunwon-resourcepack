#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 바닐라 item.vsh 확장.
// ItemDisplay의 brightness override(블록광, 하늘광)를 "모드 번호"로 쓴다.
//   블록광 15 + 하늘광 1 : 자기 몸 리그 (1인칭이면 숨김)
//   블록광 15 + 하늘광 2 : 1인칭 뷰모델 (고정 FOV, 항상 맨 앞, F5면 숨김)
//   블록광 15 + 하늘광 3 : 자기 몸 긴 무기
//   블록광 15 + 하늘광 4 : 포스트 셰이더로 보내는 데이터 픽셀
//   블록광 15 + 하늘광 5 : 잔상 (시간에 따라 사라지는 반투명 실루엣)
//   블록광 15 + 하늘광 6 : 자체발광 (명암 없음)
//   블록광 15 + 하늘광 9, 10, 11 : 무기. 남의 것, 자기 몸의 것, 1인칭의 순서이며 재질은 item.fsh가 픽셀마다 계산한다.
//   블록광 14 + 하늘광 N : 절차적 이펙트 family N
//   블록광 13 + 하늘광 N : 절차적 이펙트 family 20+N (eFam은 30+N)

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif

layout(location = 7) flat out int eFam;
layout(location = 8) flat out vec4 eData;
layout(location = 9) out vec2 eUV;
layout(location = 10) flat out vec4 eColA;
layout(location = 11) flat out vec4 eColB;
layout(location = 12) flat out vec4 eColC;
layout(location = 13) out vec3 eView;
// 몸과 칼을 숨기는 기준. x: 이보다 가까우면 숨김, y: 시야 깊이가 이보다 멀면 숨김
layout(location = 14) flat out vec2 eHide;
layout(location = 15) out float eDepth;

const float RIG_HEAD_DROP = 0.18;      // 탑승 지점(머리 위 1.8)과 눈높이(1.62)의 차이
const float VIEW_FOV_SCALE = 1.4281;   // 1 / tan(35도): 뷰모델은 항상 70도 시야로 그린다

// 몸에 비치는 저녁 빛: 해는 +z 쪽에 낮게 떠 있고, 그늘은 보랏빛 하늘을 받는다.
vec4 duskLight(vec3 n, vec4 color) {
    n = normalize(n);
    float key = max(dot(n, normalize(vec3(0.0, 0.3, 1.0))), 0.0);
    float side = max(dot(n, normalize(vec3(0.0, 0.1, -1.0))), 0.0);
    vec3 light = mix(vec3(0.40, 0.35, 0.52), vec3(0.70, 0.66, 0.86), n.y * 0.5 + 0.5);
    light += vec3(0.72, 0.44, 0.24) * key;
    light += vec3(0.30, 0.26, 0.44) * side * 0.3;
    // 해를 정면으로 받아도 흰 옷이 블룸으로 타지 않게 누른다. 블룸은 0.9부터 번진다.
    return vec4(color.rgb * min(light, vec3(0.88, 0.84, 0.84)), color.a);
}

// 벚꽃: 저녁 빛을 그대로 받으면 보라색으로 어두워진다. 꽃잎 속을 지나온 밝은 빛으로 친다.
vec4 foliageLight(vec3 n, vec4 color) {
    n = normalize(n);
    float key = max(dot(n, normalize(vec3(0.0, 0.3, 1.0))), 0.0);
    vec3 light = mix(vec3(0.74, 0.56, 0.66), vec3(1.0, 0.86, 0.92), n.y * 0.5 + 0.5) + vec3(0.26, 0.14, 0.06) * key;
    return vec4(color.rgb * min(light, vec3(1.0)), color.a);
}

// 쿼드의 어느 귀퉁이인지는 uv 소수부로 안다. 모델은 네 귀퉁이가 한 텍셀 안의 서로 다른 점을 가리키게 만들어 둔다.
// gl_VertexIndex를 쓰면 안 된다. 앞서 그린 것에 밀려 4의 배수에서 어긋나면 이펙트가 돌아가고 바닥이 사라진다.
vec2 quadCorner(float backFace) {
    vec2 f = fract(UV0 * vec2(textureSize(Sampler0, 0)));
    vec2 c = vec2(f.x < 0.5 ? -1.0 : 1.0, f.y < 0.5 ? 1.0 : -1.0);
    return backFace > 0.5 ? vec2(-c.x, c.y) : c;
}

void main() {
    vec3 pos = Position;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    int block = UV2.x >> 4;
    int sky = UV2.y >> 4;
    // 무기는 몸과 같은 위치 규칙을 따른다.
    bool weapon = block == 15 && sky >= 9 && sky <= 11;
    if (weapon) {
        sky = sky == 9 ? 15 : sky == 10 ? 3 : 2;
    }
    eFam = 0;
    eData = vec4(0.0);
    eUV = vec2(0.0);
    eColA = vec4(0.0);
    eColB = vec4(0.0);
    eColC = vec4(0.0);
    eHide = vec2(0.0);

    bool custom = false;
    bool nolight = false;

    if (block == 15 && sky >= 1 && sky <= 7) {
        custom = true;
        if (sky == 1 || sky == 3) {
            // 자기 몸: 1인칭에서는 전부 시야 안쪽에 몰려 있으므로 거리로 구분한다.
            // 꼭짓점을 옮기면 걸친 삼각형이 화면을 가르므로 픽셀 단계에서 버린다.
            eHide.x = sky == 1 ? 2.45 : 3.25;
        } else if (sky == 2 || sky == 7) {
            // 1인칭 뷰모델. 7은 팔이다. 칼끝과 달리 멀리 뻗지 않으므로 더 가까이에서 버려 3인칭에 비치지 않게 한다.
            pos.y -= RIG_HEAD_DROP;
            // 3인칭이면 카메라가 네 칸 물러나 모두 이 깊이 밖으로 나간다.
            eHide.y = sky == 7 ? 2.4 : 3.75;
            vec4 clip = ProjMat * ModelViewMat * vec4(pos, 1.0);
            float fovFix = VIEW_FOV_SCALE / ProjMat[1][1];
            clip.xy *= fovFix;
            // 깊이 방향(역방향 Z 포함)에 상관없이 세상보다 앞에 그려지도록 가까운 값으로 옮긴다.
            float vz = max(-(ModelViewMat * vec4(pos, 1.0)).z, 0.0);
            float dp = 0.06 + vz * 0.02;
            clip.z = (ProjMat[2][2] * -dp + ProjMat[3][2]) / dp * clip.w;
            gl_Position = clip;
        } else if (sky == 4) {
            // 데이터 픽셀: 화면 왼쪽 아래 구석의 픽셀로 강제 배치한다.
            int slot = int(texelFetch(Sampler0, ivec2(UV0 * vec2(textureSize(Sampler0, 0))), 0).r * 255.0 + 0.5);
            vec2 c = quadCorner(0.0) * 0.5 + 0.5;
            vec2 px = vec2(float(slot % 8) + c.x, c.y);
            vec2 ndc = px / ScreenSize * 2.0 - 1.0;
            // 어떤 물체에도 가려지지 않게 카메라 바로 앞 깊이에 찍는다. 깊이 방향은 투영 행렬을 따른다.
            float near = 0.055;
            gl_Position = vec4(ndc, (ProjMat[2][2] * -near + ProjMat[3][2]) / near, 1.0);
            eFam = 100;
            eColA = Color;
        } else if (sky == 5) {
            // 잔상: 틴트로 (시작, 수명, 색 인덱스)를 받는다.
            int d = (int(Color.r * 255.0 + 0.5) << 16) | (int(Color.g * 255.0 + 0.5) << 8) | int(Color.b * 255.0 + 0.5);
            float start = float((d >> 16) & 255);
            float life = float(((d >> 10) & 63) + 1);
            float now = GameTime * 24000.0;
            float age = mod(now - start, 256.0);
            eFam = 90;
            // 카메라 코앞에 남은 잔상은 화면을 큰 판으로 가린다.
            eHide.x = 3.0;
            eData = vec4(age / life, life, float(d & 1023), 0.0);
            eColA = vec4(float((d >> 7) & 7) / 7.0, float((d >> 4) & 7) / 7.0, float(d & 15) / 15.0, 1.0);
            eUV = vec2(0.0);
        } else if (sky == 6) {
            nolight = true;
        }
    } else if (block == 15 && (sky == 15 || sky == 8)) {
        // 남의 몸과 무기: 카메라 코앞에 오면 화면을 덮지 않게 성글게 지운다. 음수는 이 거리부터 지운다는 뜻이다.
        eHide.x = -1.25;
    } else if (block == 14 || block == 13) {
        // 절차적 이펙트. 틴트 24비트: 시작틱 8, 수명 6, a 6, b 4
        custom = true;
        int d = (int(Color.r * 255.0 + 0.5) << 16) | (int(Color.g * 255.0 + 0.5) << 8) | int(Color.b * 255.0 + 0.5);
        float start = float((d >> 16) & 255);
        float life = float(((d >> 10) & 63) + 1);
        float a = float((d >> 4) & 63);
        float b = float(d & 15);
        float now = GameTime * 24000.0;
        float age = mod(now - start, 256.0);
        eFam = (block == 14 ? 10 : 30) + sky;
        eData = vec4(age / life, life, a, b);
        // 뒷면은 팔레트 텍스처의 다음 줄(알파 표식)로 구분한다.
        ivec2 tsz = textureSize(Sampler0, 0);
        ivec2 tx = ivec2(UV0 * vec2(tsz));
        eColA = texelFetch(Sampler0, tx + ivec2(0, 0), 0);
        eColB = texelFetch(Sampler0, tx + ivec2(1, 0), 0);
        eColC = texelFetch(Sampler0, tx + ivec2(2, 0), 0);
        float back = texelFetch(Sampler0, tx + ivec2(3, 0), 0).r;
        eUV = quadCorner(back);
        nolight = true;
        if (eFam == 33) {
            // 바닥 그림이 아틀라스에서 시작하는 자리. 줄인 그림을 찾을 때 쓴다.
            // 그림 네 구석에 귀퉁이 번호가 칠해져 있다(gen_floor.with_mips). uv는 구석에서 반 칸 안쪽을 가리킨다.
            vec2 corner = step(vec2(0.5), eColA.rg);
            eData.xy = round(UV0 * vec2(tsz) - corner * 2047.0 - 0.5);
        }
        if (eFam == 25) {
            // 1인칭 베기 궤적: 뷰모델과 같은 시야로 그린다. 3인칭이면 머리 앞에 그대로 떠 있다.
            vec3 head = vec3(pos.x, pos.y - RIG_HEAD_DROP, pos.z);
            vec4 view = ModelViewMat * vec4(head, 1.0);
            if (-view.z < 2.5) {
                vec4 clip = ProjMat * view;
                clip.xy *= VIEW_FOV_SCALE / ProjMat[1][1];
                float dp = 0.17;
                clip.z = (ProjMat[2][2] * -dp + ProjMat[3][2]) / dp * clip.w;
                gl_Position = clip;
            }
        }
    }

    if (weapon) {
        // 틴트의 아래 비트가 재질이다: 파랑 두 비트는 금속 정도, 초록 한 비트는 스스로 빛나는 부위 (gen_weapons.tint_value)
        ivec3 c = ivec3(Color.rgb * 255.0 + 0.5);
        custom = true;
        eFam = 5;
        eData = vec4(float(c.b & 3), float(c.g & 1), sky == 2 ? 1.0 : 0.0, 0.0);
        eColA = Color;
        eColB = vec4(Normal, 0.0);
    }

    eView = pos;
    eDepth = -(ModelViewMat * vec4(pos, 1.0)).z;

    if (eFam == 12 || eFam == 13 || eFam == 17 || eFam == 18 || (eFam >= 30 && eFam <= 32) || eFam == 35 || eFam == 36) {
        // 화면을 보는 이펙트가 바닥이나 몸을 뚫으면 만나는 곳에 직선이 생긴다. 깊이만 카메라 쪽으로 당긴다.
        if (abs((mat3(ModelViewMat) * Normal).z) > 0.97) {
            float dp = max(eDepth - 4.0, 0.3);
            gl_Position.z = (ProjMat[2][2] * -dp + ProjMat[3][2]) / dp * gl_Position.w;
        }
    }

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    #endif

    if (eFam >= 10) {
        vertexColor = vec4(1.0);
    } else if (block == 15 && (sky == 2 || sky == 7)) {
        // 뷰모델은 고개를 돌려도 밝기가 변하지 않도록 시야 기준으로 빛을 준다.
        vec3 vn = mat3(ModelViewMat) * Normal;
        vertexColor = minecraft_mix_light(normalize(vec3(0.25, 0.8, 0.55)), normalize(vec3(-0.6, 0.25, 0.5)), vn, Color);
        vertexColor.rgb *= 0.84;
    } else if (block == 15 && sky == 8) {
        vertexColor = foliageLight(Normal, Color);
    } else if (block == 15 && (sky == 1 || sky == 3 || sky == 15)) {
        vertexColor = duskLight(Normal, Color);
    } else if (nolight) {
        vertexColor = Color;
    } else {
        vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    }

    #ifndef OIT_ALPHA_ONLY
    if (custom) {
        lightMapColor = vec4(1.0);
        overlayColor = vec4(0.0, 0.0, 0.0, 1.0);
        if ((sky == 2 || sky == 7) && block == 15) {
            sphericalVertexDistance = 0.0;
            cylindricalVertexDistance = 0.0;
        }
        if (eFam >= 10) {
            sphericalVertexDistance = 0.0;
            cylindricalVertexDistance = 0.0;
        }
    } else {
        lightMapColor = sample_lightmap(Sampler2, UV2);
        overlayColor = texelFetch(Sampler1, UV1, 0);
    }
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
