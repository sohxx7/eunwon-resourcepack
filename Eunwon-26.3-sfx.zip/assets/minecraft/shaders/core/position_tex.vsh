#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 해 사각형을 화면 전체로 펼쳐 산수 파노라마를 그린다. 이 셰이더를 쓰는 건 해와 달뿐이다.

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec3 skyRay;
layout(location = 2) flat out int skyMode;
layout(location = 3) flat out vec2 skyCorner;
layout(location = 4) flat out vec2 skyUv;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    skyRay = vec3(0.0);
    skyMode = 0;
    skyCorner = vec2(0.0);
    skyUv = UV0;

    vec3 center = ModelViewMat[3].xyz;
    if (Position.y == 0.0 && abs(Position.x) == 1.0 && length(center) > 50.0) {
        vec3 col1 = normalize(ModelViewMat[1].xyz);
        if (dot(center, col1) < 0.0) {
            // 달은 그리지 않는다.
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        } else {
            vec3 col0 = normalize(ModelViewMat[0].xyz);
            vec3 col2 = normalize(ModelViewMat[2].xyz);
            vec2 ndc = vec2(Position.x, Position.z);
            gl_Position = vec4(ndc, 0.0, 1.0);
            vec3 viewRay = vec3(ndc.x / ProjMat[0][0], ndc.y / ProjMat[1][1], -1.0);
            skyRay = vec3(dot(viewRay, col0), dot(viewRay, col1), dot(viewRay, col2));
            skyMode = 1;
            // 꼭짓점 위치: (0,0)이 스프라이트 왼쪽 위
            skyCorner = vec2(Position.x * 0.5 + 0.5, Position.z * 0.5 + 0.5);
        }
    }
}
