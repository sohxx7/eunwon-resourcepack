#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협 HUD: 글자 색 24비트를 자료로 쓴다.
//   R이 0xD6~0xFD이고 글자 그림 네 귀퉁이에 표식이 있으면 HUD 요소다. R이 요소 번호, G와 B가 값이다.
//   R이 0xFE면 일반 글자를 지정한 자리로 옮긴다. G가 위치 번호, B가 색 번호다.
// 위치는 화면 높이의 1/1080을 단위로 잡아 GUI 배율과 상관없이 같은 크기로 보인다.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:globals.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out ivec3 hudData;
layout(location = 5) out vec2 hudUV;
layout(location = 6) flat out vec2 hudSize;

#ifdef IS_GUI
const vec3 LABEL_COLORS[8] = vec3[8](
    vec3(1.0, 0.97, 0.90),   // 0 흰 먹빛
    vec3(1.0, 0.82, 0.42),   // 1 금빛
    vec3(1.0, 0.36, 0.30),   // 2 다홍
    vec3(0.62, 0.84, 1.0),   // 3 하늘
    vec3(0.72, 0.72, 0.76),  // 4 회색
    vec3(0.78, 1.0, 0.62),   // 5 연두
    vec3(1.0, 0.62, 0.82),   // 6 분홍
    vec3(0.86, 0.72, 1.0)    // 7 보라
);

bool isMark(ivec2 t) {
    vec4 c = texelFetch(Sampler0, t, 0);
    return abs(c.r - 1.0 / 255.0) < 0.002 && abs(c.g - 2.0 / 255.0) < 0.002 && abs(c.b - 3.0 / 255.0) < 0.002 && c.a > 0.9;
}

// 요소별 위치. xy: 가운데 좌표(가로는 화면 가운데 기준, 세로는 anchorY 기준), zw: 크기
void layout_of(int id, int g, int b, out vec2 center, out vec2 size, out float anchorY) {
    anchorY = 1.0; // 1: 아래 기준, 0: 위 기준, 0.5: 가운데 기준
    center = vec2(0.0);
    size = vec2(64.0);
    if (id == 0xE0) { center = vec2(0.0, -122.0); size = vec2(620.0, 30.0); }
    else if (id == 0xE1) { center = vec2(0.0, -122.0); size = vec2(620.0, 30.0); }
    else if (id == 0xE2) { center = vec2(0.0, -99.0); size = vec2(520.0, 13.0); }
    else if (id == 0xE3) { center = vec2(0.0, -148.0); size = vec2(430.0, 12.0); }
    else if (id == 0xE4) { center = vec2(0.0, 66.0); size = vec2(520.0, 18.0); anchorY = 0.0; }
    else if (id == 0xE5) { center = vec2(0.0, 66.0); size = vec2(520.0, 18.0); anchorY = 0.0; }
    else if (id == 0xE6) { center = vec2(0.0, 88.0); size = vec2(340.0, 8.0); anchorY = 0.0; }
    else if (id >= 0xE7 && id <= 0xEA) { center = vec2(-215.0 + float(id - 0xE7) * 86.0, -56.0); size = vec2(68.0); }
    else if (id == 0xEB) { center = vec2(129.0, -56.0); size = vec2(68.0); }
    else if (id == 0xEC) { center = vec2(215.0, -56.0); size = vec2(68.0); }
    else if (id == 0xED) { center = vec2(292.0, -99.0); size = vec2(66.0, 18.0); }
    else if (id == 0xEE) { center = vec2(0.0, 0.0); size = vec2(64.0); anchorY = 0.5; }
    else if (id == 0xEF) { center = vec2(0.0, 0.0); size = vec2(150.0); anchorY = 0.5; }
    else if (id == 0xF0) { center = vec2(350.0, -60.0); size = vec2(375.0, 138.0); anchorY = 0.5; }
    else if (id == 0xF1) { center = vec2(-350.0, -60.0); size = vec2(375.0, 138.0); anchorY = 0.5; }
    else if (id == 0xF2) {
        // b의 맨 윗비트: 절초처럼 싸움을 가리면 안 되는 글자는 위쪽에 작게
        bool small = (b & 128) != 0;
        center = vec2(0.0, small ? -250.0 : -40.0);
        size = vec2(small ? 230.0 : 430.0);
        anchorY = 0.5;
    }
    else if (id >= 0xF3 && id <= 0xF5) { center = vec2(560.0 + float(id - 0xF3) * 46.0, 70.0); size = vec2(60.0, 78.0); anchorY = 0.5; }
    else if (id == 0xF6) { center = vec2(560.0 + float(b) * 46.0 + 14.0, 70.0); size = vec2(66.0); anchorY = 0.5; }
    else if (id == 0xF7) { center = vec2(-348.0, -118.0); size = vec2(72.0); }
    else if (id == 0xDF) { center = vec2(372.0, -122.0); size = vec2(76.0); }
    else if (id == 0xF8) { center = vec2(-290.0 + float(g) * 40.0, -174.0); size = vec2(36.0); }
    else if (id == 0xF9) { center = vec2(-215.0 + float(b) * 86.0 + 26.0, -34.0); size = vec2(26.0); }
    else if (id == 0xFB) { center = vec2(-215.0 + float(b) * 86.0, -12.0); size = vec2(96.0, 24.0); }
    else if (id == 0xFC) {
        // 첫 제목. 글꼴 칸에 들어가게 자른 조각이며, 이음매에서 2픽셀씩 겹친다.
        center = vec2((float(g & 3) - 1.5) * 246.0, (float(g >> 2) - 0.5) * 246.0 - 56.0);
        size = vec2(250.0);
        anchorY = 0.5;
    }
    else if (id == 0xFD) { center = vec2(0.0, -24.0); size = vec2(1240.0, 350.0); anchorY = 0.5; }
    // 관전: 지금 겨루는 두 사람의 막대를 위쪽에 마주 보게 놓는다. 왼쪽이 먼저 불린 사람이다.
    else if (id == 0xD8 || id == 0xD9) { center = vec2(-300.0, 66.0); size = vec2(500.0, 18.0); anchorY = 0.0; }
    else if (id == 0xDB || id == 0xDC) { center = vec2(300.0, 66.0); size = vec2(500.0, 18.0); anchorY = 0.0; }
    else if (id == 0xDA) { center = vec2(-300.0, 88.0); size = vec2(320.0, 8.0); anchorY = 0.0; }
    else if (id == 0xDD) { center = vec2(300.0, 88.0); size = vec2(320.0, 8.0); anchorY = 0.0; }
    else if (id == 0xD6) { center = vec2(-596.0, 74.0); size = vec2(64.0); anchorY = 0.0; }
    else if (id == 0xD7) { center = vec2(596.0, 74.0); size = vec2(64.0); anchorY = 0.0; }
    else if (id == 0xFA) {
        // 시야 밖 상대: g는 앞을 0으로 시계 방향 각도(256이 한 바퀴)
        float a = float(g) / 256.0 * 6.2831853;
        center = vec2(sin(a), -cos(a)) * 200.0;
        size = vec2(84.0);
        anchorY = 0.5;
    }
}
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    hudData = ivec3(0);
    hudUV = vec2(0.0);
    hudSize = vec2(1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    ivec3 c = ivec3(Color.rgb * 255.0 + 0.5);
    if (c.r == 0xFE) {
        // 일반 글자 옮기기
        vec2 gui = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        float unit = gui.y / 1080.0;
        vec2 from = vec2(gui.x * 0.5, 0.0);
        vec2 to = vec2(gui.x * 0.5, 0.0);
        float scale = 1.0;
        if (c.g == 1) {
            // 액션바: 내 체력 숫자
            from.y = gui.y - 72.0;
            to.y = gui.y - 122.0 * unit - 2.5 * 0.9;
            scale = 0.9;
        } else if (c.g == 2) {
            // 부제목: 초식 이름
            from.y = gui.y * 0.5 + 10.0;
            to.y = gui.y - 226.0 * unit;
            scale = 0.82;
        } else if (c.g == 3) {
            // 두 번째 우두머리 막대: 상대 이름
            from.y = 22.0;
            to.y = 30.0 * unit;
            scale = max(0.7, 32.0 * unit / 9.0);
        } else if (c.g == 4 || c.g == 5) {
            // 관전: 두 사람의 이름. 4는 두 번째, 5는 세 번째 우두머리 막대 제목이고 각자 제 막대 위로 간다.
            from.y = c.g == 4 ? 22.0 : 41.0;
            to.y = 30.0 * unit;
            to.x += (c.g == 4 ? -300.0 : 300.0) * unit;
            scale = max(0.7, 32.0 * unit / 9.0);
        }
        vec2 p = to + (Position.xy - from) * scale;
        gl_Position = ProjMat * ModelViewMat * vec4(p, Position.z, 1.0);
        // 8번 비트는 그 글자의 그림자다.
        vertexColor = vec4((c.b & 8) != 0 ? vec3(0.015, 0.012, 0.02) : LABEL_COLORS[c.b & 7], Color.a);
    } else if (c.r >= 0xD6 && c.r <= 0xFD) {
        ivec2 sz = textureSize(Sampler0, 0);
        vec2 tx = UV0 * vec2(sz);
        ivec2 t = ivec2(floor(tx + 0.5));
        vec2 corner = vec2(-1.0);
        if (isMark(t)) corner = vec2(0.0, 0.0);
        else if (isMark(t + ivec2(-1, 0))) corner = vec2(1.0, 0.0);
        else if (isMark(t + ivec2(0, -1))) corner = vec2(0.0, 1.0);
        else if (isMark(t + ivec2(-1, -1))) corner = vec2(1.0, 1.0);
        if (corner.x >= 0.0) {
            vec2 center, size;
            float anchorY;
            layout_of(c.r, c.g, c.b, center, size, anchorY);
            float unit = ScreenSize.y / 1080.0;
            float baseY = anchorY == 0.0 ? 0.0 : anchorY == 1.0 ? ScreenSize.y : ScreenSize.y * 0.5;
            vec2 pos = vec2(ScreenSize.x * 0.5 + center.x * unit, baseY + center.y * unit);

            float s = 1.0;
            vec2 jitter = vec2(0.0);
            if (c.r >= 0xF0 && c.r <= 0xF2) {
                // 도장: 크게 찍혔다가 자리 잡는다.
                float now = GameTime * 24000.0;
                float age = mod(now - float(c.g), 256.0);
                float k = clamp(age / 2.5, 0.0, 1.0);
                s = mix(c.r == 0xF2 ? 2.1 : 1.7, 1.0, 1.0 - (1.0 - k) * (1.0 - k) * (1.0 - k));
                if (age < 5.0) {
                    float m = (5.0 - age) * 1.1 * unit;
                    jitter = vec2(sin(now * 9.1), cos(now * 7.3)) * m;
                }
            } else if (c.r >= 0xF3 && c.r <= 0xF5) {
                float now = GameTime * 24000.0;
                float age = mod(now - float(c.g), 256.0);
                float k = clamp(age / 3.0, 0.0, 1.0);
                s = mix(1.5, 1.0, k);
            } else if (c.r == 0xEE) {
                float now = GameTime * 24000.0;
                float age = mod(now - float(c.g), 256.0);
                s = 0.7 + clamp(age / 4.0, 0.0, 1.0) * 0.5;
            }
            vec2 p = pos + (corner - 0.5) * size * unit * s + jitter;
            vec2 ndc = p / ScreenSize * 2.0 - 1.0;
            gl_Position = vec4(ndc.x, -ndc.y, 0.0, 1.0);
            hudData = c;
            hudUV = corner;
            hudSize = size * unit * s;
            vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
#endif
}
