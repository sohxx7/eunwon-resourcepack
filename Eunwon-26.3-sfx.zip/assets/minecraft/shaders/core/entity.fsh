#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 바닐라 entity.fsh 확장. 1인칭 팔은 머리 모델을 쓰므로 스킨에서 읽을 자리를 팔로 옮긴다. (entity.vsh 참고)

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

layout(location = 8) flat in int armMode;
layout(location = 9) in float armDepth;
layout(location = 10) flat in int skinPart;
layout(location = 11) flat in int skinState;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

// 표시물은 스킨 12칸보다 긴 30칸으로 늘려 두었다. 팔 끝이 화면에 드러나지 않게 하려는 것이다.
const float ARM_CELLS = 30.0;
// 덧입는 층은 머리 모델에서 사방으로 반 칸 커서, 늘리고 나면 양끝으로 이만큼 더 나간다.
const float SKULL_OVER = 0.5;
const float SLEEVE_OVER = SKULL_OVER / 8.0 * ARM_CELLS;

// 머리 모델의 uv(8x8x8 상자)를 같은 면의 팔 자리(4x12x4 상자)로 옮긴다. 면이 맞닿은 꼭짓점은 uv만으로 구분되지 않아 픽셀 단계에서 푼다.
vec2 armUv() {
    vec2 p = texCoord0 * 64.0;
    bool sleeve = p.x >= 32.0;
    if (sleeve) {
        p.x -= 32.0;
    }
    bool left = (armMode & 2) != 0;
    float w = (armMode & 4) != 0 ? 3.0 : 4.0;
    vec2 o = left ? (sleeve ? vec2(48.0, 48.0) : vec2(32.0, 48.0)) : (sleeve ? vec2(40.0, 32.0) : vec2(40.0, 16.0));
    if (p.y < 8.0) {
        // 덧입는 층의 뚜껑은 손끝 앞에 떠 있으므로 그리지 않는다.
        if (sleeve) {
            return vec2(-1.0);
        }
        // 어깨 쪽 면과 손끝 쪽 면
        bool top = p.x < 16.0;
        vec2 f = (p - vec2(top ? 8.0 : 16.0, 0.0)) / 8.0;
        return (o + vec2(top ? 4.0 : 4.0 + w, 0.0) + f * vec2(w, 4.0)) / 64.0;
    }
    int side = clamp(int(p.x / 8.0), 0, 3);
    float across = (p.x - float(side) * 8.0) / 8.0;
    // 손끝부터 12칸은 제 크기로 읽고, 어깨를 넘는 칸은 맨 윗줄 석 칸을 되풀이해 소매가 이어지게 한다.
    float cells = (16.0 - p.y) / 8.0 * ARM_CELLS;
    if (sleeve) {
        // 바탕 팔과 칸을 맞춘다. 손끝을 넘어가는 자리는 버린다.
        cells = cells * (ARM_CELLS + 2.0 * SLEEVE_OVER) / ARM_CELLS - SLEEVE_OVER;
        if (cells < 0.0) {
            return vec2(-1.0);
        }
    }
    float along = cells <= 12.0 ? 12.0 - cells : mod(cells - 12.0, 3.0);
    float x;
    float width;
    if (side == 0) {
        x = 0.0;
        width = 4.0;
    } else if (side == 1) {
        x = 4.0;
        width = w;
    } else if (side == 2) {
        x = 4.0 + w;
        width = 4.0;
    } else {
        x = 8.0 + w;
        width = w;
    }
    return (o + vec2(x + across * width, 4.0 + clamp(along, 0.0, 11.999))) / 64.0;
}

// 머리 모델의 uv를 몸통이나 팔다리 한 토막의 스킨 자리로 옮긴다. 음수를 돌려주면 그리지 않는다.
// 부위: 1 몸통, 2 3 오른팔, 4 5 왼팔, 6 오른허벅지, 7 오른다리(1인칭), 8 왼허벅지, 9 왼다리(1인칭), 10 11 오른정강이와 발, 12 13 왼정강이와 발
// 줄 범위는 tools/gen_rig.py의 SKIN_PARTS와 맞물린다. 관절에서 겹치는 토막이 같은 줄을 읽어 곧게 폈을 때 무늬가 이어진다.
vec2 bodyUv() {
    int part = skinPart & 15;
    if (part == 0) {
        return texCoord0;
    }
    vec2 p = texCoord0 * 64.0;
    bool sleeve = p.x >= 32.0;
    if (sleeve) {
        p.x -= 32.0;
    }
    vec2 o, o2;
    float w = 4.0, d = 4.0, v0 = 0.0, v1 = 12.0;
    bool endTop = true, endBottom = true;
    if (part == 1) {
        o = vec2(16.0, 16.0);
        o2 = vec2(16.0, 32.0);
        w = 8.0;
    } else if (part <= 5) {
        bool left = part >= 4;
        o = left ? vec2(32.0, 48.0) : vec2(40.0, 16.0);
        o2 = left ? vec2(48.0, 48.0) : vec2(40.0, 32.0);
        w = (skinPart & 16) != 0 ? 3.0 : 4.0;
        bool lower = part == 3 || part == 5;
        v0 = lower ? 5.18 : 0.0;
        v1 = lower ? 12.0 : 7.49;
        endTop = !lower;
        endBottom = lower;
    } else {
        bool left = part == 8 || part == 9 || part >= 12;
        o = left ? vec2(16.0, 48.0) : vec2(0.0, 16.0);
        o2 = left ? vec2(0.0, 48.0) : vec2(0.0, 32.0);
        if (part == 6 || part == 8) {
            v1 = 7.0;
            endBottom = false;
        } else if (part == 7 || part == 9) {
            v0 = 6.0;
            endTop = false;
        } else if (part == 10 || part == 12) {
            v0 = 5.0;
            v1 = 10.0;
            endTop = false;
            endBottom = false;
        } else {
            v0 = 9.0;
            endTop = false;
        }
    }
    vec2 base = sleeve ? o2 : o;
    if (p.y < 8.0) {
        // 덧입는 층의 뚜껑은 토막 사이에 떠 있으므로 그리지 않는다.
        if (sleeve) {
            return vec2(-1.0);
        }
        bool top = p.x < 16.0;
        vec2 f = (p - vec2(top ? 8.0 : 16.0, 0.0)) / 8.0;
        if (top ? !endTop : !endBottom) {
            // 관절 속의 뚜껑: 손바닥이나 발바닥 그림 대신 그 줄의 색을 잇는다.
            return (base + vec2(d + f.x * w, d + (top ? v0 : v1 - 0.5))) / 64.0;
        }
        return (base + vec2(top ? d : d + w, 0.0) + f * vec2(w, d)) / 64.0;
    }
    int side = clamp(int(p.x / 8.0), 0, 3);
    float across = (p.x - float(side) * 8.0) / 8.0;
    float along = clamp((p.y - 8.0) / 8.0, 0.0, 0.999);
    if (sleeve) {
        // 덧입는 층은 머리 모델에서 사방으로 커서, 늘리고 나면 손끝과 발끝 너머로 나간다. 바탕과 줄을 맞추고 나간 곳은 버린다.
        along = along * (8.0 + 2.0 * SKULL_OVER) / 8.0 - SKULL_OVER / 8.0;
        if (along < 0.0 || along >= 1.0) {
            return vec2(-1.0);
        }
    }
    float row = mix(v0, v1, along);
    float x = side == 0 ? 0.0 : side == 1 ? d : side == 2 ? d + w : d + w + d;
    float width = side == 0 || side == 2 ? d : w;
    return (base + vec2(x + across * width, d + row)) / 64.0;
}

void main() {
    vec4 color;
    if (skinPart >= 0) {
        // 1인칭에서 자기 몸은 눈 둘레에 몰려 있다. 남의 몸은 카메라를 덮을 만큼 가까울 때만 지운다.
        bool mine = skinState >= 8 && (skinState & 1) != 0;
        if (skinState == 7 ? armDepth > 2.4 : mine ? armDepth < 2.45 : armDepth < 0.5) {
            discard;
        }
        vec2 skinTex = bodyUv();
        if (skinTex.x < 0.0) {
            discard;
        }
        color = textureLod(Sampler0, skinTex, 0.0);
        if (skinState >= 8 && (skinState & 2) != 0) {
            color.rgb = mix(color.rgb, vec3(1.0, 0.31, 0.28), 0.7);
        } else if (skinState >= 8 && (skinState & 4) != 0) {
            color.rgb = vec3(dot(color.rgb, vec3(0.3, 0.55, 0.15))) * vec3(0.5, 0.5, 0.56);
        }
    } else if (armMode != 0) {
        // 3인칭이면 카메라가 네 칸 물러나 이 깊이 밖으로 나간다.
        if (armDepth > 2.4) {
            discard;
        }
        vec2 armTex = armUv();
        if (armTex.x < 0.0) {
            discard;
        }
        color = textureLod(Sampler0, armTex, 0.0);
    } else {
        color = texture(Sampler0, texCoord0);
    }

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
