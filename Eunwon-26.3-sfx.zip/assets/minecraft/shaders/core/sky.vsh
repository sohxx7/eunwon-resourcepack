#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 하늘 원반의 둘레를 지평선 아래로 내려 안개색 띠가 드러나지 않게 한다.

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

void main() {
    vec3 p = Position;
    if (length(p.xz) > 1.0 && p.y > 0.0) {
        p.y = -64.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(p, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}
