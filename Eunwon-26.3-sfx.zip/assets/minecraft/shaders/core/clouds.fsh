#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 하늘은 파노라마에 이미 그려져 있으므로 구름 블록은 그리지 않는다.
void main() {
    discard;
}
