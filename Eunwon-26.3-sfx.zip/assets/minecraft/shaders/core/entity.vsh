#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협: 바닐라 entity.vsh 확장.
// 플레이어 머리 아이템을 팔 비율로 늘린 표시물이 1인칭 팔이다. 블록광 15 + 하늘광이 팔 번호다.
//   1번 비트: 팔 표시, 2번 비트: 왼팔, 4번 비트: 얇은 팔(알렉스 체형)
// 뷰모델의 시야와 깊이 처리는 item.vsh의 하늘광 2와 같다.
// 몸도 같은 표시물로 그린다. 하늘광이 스킨의 어느 부위인지(0 머리, 1 몸통, 2~5 팔, 6~9 다리),
//   10~13 정강이와 발) 블록광이 상태다. 7: 1인칭 다리, 8 + (1: 자기 몸, 2: 맞아서 번쩍임, 4: 관전자)

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

uniform sampler2D Sampler0;

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

layout(location = 8) flat out int armMode;
layout(location = 9) out float armDepth;
layout(location = 10) flat out int skinPart;
layout(location = 11) flat out int skinState;

const float RIG_HEAD_DROP = 0.18;      // 탑승 지점(머리 위 1.8)과 눈높이(1.62)의 차이
const float VIEW_FOV_SCALE = 1.4281;   // 1 / tan(35도): 뷰모델은 항상 70도 시야로 그린다

// 얇은 팔 스킨은 팔 앞뒤가 3칸이라 안 쓰는 칸이 비어 있거나 한 색으로 칠해져 있다. 서버가 체형을 모를 때 이것으로 판단한다.
bool thinArmSkin() {
    ivec2 cells[6] = ivec2[6](ivec2(54, 20), ivec2(55, 20), ivec2(54, 31), ivec2(55, 31), ivec2(50, 16), ivec2(51, 19));
    vec4 first = texelFetch(Sampler0, cells[0], 0);
    for (int i = 1; i < 6; i++) {
        vec4 c = texelFetch(Sampler0, cells[i], 0);
        if (c.a > 0.01 && distance(c.rgb, first.rgb) > 0.002) {
            return false;
        }
    }
    return true;
}

// 몸에 비치는 저녁 빛. item.vsh의 duskLight와 같아야 옷과 살이 같은 빛을 받는다.
vec4 skinLight(vec3 n, vec4 color) {
    n = normalize(n);
    float key = max(dot(n, normalize(vec3(0.0, 0.3, 1.0))), 0.0);
    float side = max(dot(n, normalize(vec3(0.0, 0.1, -1.0))), 0.0);
    vec3 light = mix(vec3(0.40, 0.35, 0.52), vec3(0.70, 0.66, 0.86), n.y * 0.5 + 0.5);
    light += vec3(0.72, 0.44, 0.24) * key;
    light += vec3(0.30, 0.26, 0.44) * side * 0.3;
    // 블룸은 0.9부터 번진다. 흰 스킨이 얼굴까지 타지 않게 그 아래로 누른다.
    return vec4(color.rgb * min(light, vec3(0.88, 0.84, 0.84)), color.a);
}

void main() {
    vec3 pos = Position;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    int block = UV2.x >> 4;
    int sky = UV2.y >> 4;
    armMode = block == 15 && sky <= 7 && (sky & 1) == 1 && textureSize(Sampler0, 0) == ivec2(64) ? sky : 0;
    armDepth = 0.0;
    skinPart = -1;
    skinState = 0;
    bool skinSized = textureSize(Sampler0, 0) == ivec2(64);
    if (block >= 7 && block <= 14 && skinSized) {
        skinPart = sky;
        skinState = block;
        if (sky >= 2 && sky <= 5 && thinArmSkin()) {
            skinPart |= 16;
        }
        armDepth = -(ModelViewMat * vec4(pos, 1.0)).z;
    }
    if (armMode != 0 || block == 7 && skinSized) {
        if (armMode != 0 && thinArmSkin()) {
            armMode |= 4;
        }
        pos.y -= RIG_HEAD_DROP;
        vec4 view = ModelViewMat * vec4(pos, 1.0);
        armDepth = -view.z;
        vec4 clip = ProjMat * view;
        clip.xy *= VIEW_FOV_SCALE / ProjMat[1][1];
        // 깊이 방향(역방향 Z 포함)에 상관없이 세상보다 앞에 그려지도록 가까운 값으로 옮긴다. 칼과 같은 계산이어야 서로 제대로 가린다.
        float dp = 0.06 + max(armDepth, 0.0) * 0.02;
        clip.z = (ProjMat[2][2] * -dp + ProjMat[3][2]) / dp * clip.w;
        gl_Position = clip;
    }

    bool flatView = armMode != 0 || skinState == 7;
    sphericalVertexDistance = flatView ? 0.0 : fog_spherical_distance(pos);
    cylindricalVertexDistance = flatView ? 0.0 : fog_cylindrical_distance(pos);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vec4 tint = Color;
    if (flatView) {
        // 칼과 같은 빛을 시야 기준으로 준다. 고개를 돌려도 팔 밝기가 변하지 않는다.
        light = minecraft_compute_light(normalize(vec3(0.25, 0.8, 0.55)), normalize(vec3(-0.6, 0.25, 0.5)), normalize(mat3(ModelViewMat) * Normal));
        tint.rgb *= 0.9;
    }
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, tint);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, tint);
    if (skinPart >= 0 && !flatView) {
        vertexPerFaceColorBack = skinLight(-Normal, Color);
        vertexPerFaceColorFront = skinLight(Normal, Color);
    }
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = skinPart >= 0 && !flatView ? skinLight(Normal, Color) : minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = armMode != 0 || skinPart >= 0 ? vec4(1.0) : sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    // 관전 모드는 투명한 몸을 알파 0x26으로 비춰 그린다(LivingEntityRenderer). 이 판의 몸은 스킨 토막으로 따로 그리므로
    // 그 잔상은 그리지 않는다. 다른 것은 이 알파를 쓰지 않는다.
    if (abs(Color.a - 38.0 / 255.0) < 0.002) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }
}
