#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float l = max(c.r, max(c.g, c.b));
    float k = smoothstep(0.90, 1.0, l);
    k *= k;
    fragColor = vec4(c * k, 1.0);
}
