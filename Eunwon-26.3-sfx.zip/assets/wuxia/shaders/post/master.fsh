#version 330
#extension GL_ARB_separate_shader_objects : require

// 무협 화면 마무리: 화면 구석 8픽셀로 받은 사건을 읽어 흔들림, 번쩍임, 수묵 전환을 입히고,
// 항상 블룸과 색보정을 건다. 슬롯 형식은 Screen.java 참고.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;
uniform sampler2D BloomSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const float PI = 3.14159265;

float now() {
    return GameTime * 24000.0;
}

// x: 진행도(0~1, 꺼져 있으면 2), y: 세기, z: 추가값
vec3 slot(int i) {
    ivec3 b = ivec3(texelFetch(InSampler, ivec2(i, 0), 0).rgb * 255.0 + 0.5);
    int d = (b.r << 16) | (b.g << 8) | b.b;
    if (d == 0) return vec3(2.0, 0.0, 0.0);
    float start = float((d >> 16) & 255);
    float life = float(((d >> 10) & 63) + 1);
    float amp = float((d >> 4) & 63) / 63.0;
    float extra = float(d & 15);
    float age = mod(now() - start, 256.0);
    return vec3(age / life, amp, extra);
}

float hash12(vec2 p) {
    p = fract(p * vec2(443.897, 441.423));
    p += dot(p, p.yx + 19.19);
    return fract((p.x + p.y) * p.x);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1, 0)), f.x), mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), f.x), f.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + 11.3;
        a *= 0.5;
    }
    return v;
}
float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 scene(vec2 uv) {
    return texture(InSampler, uv).rgb;
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    bool valid = false;
    {
        ivec3 m = ivec3(texelFetch(InSampler, ivec2(7, 0), 0).rgb * 255.0 + 0.5);
        valid = m.r == 0xA5 && m.g == 0x5A && m.b == 0xC3;
    }

    vec2 uv = texCoord;
    vec2 centered = uv - 0.5;
    float aspect = OutSize.x / OutSize.y;

    float shakeAmt = 0.0, zoomAmt = 0.0, chromaAmt = 0.0;
    vec3 flashCol = vec3(1.0);
    float flashAmt = 0.0, impactAmt = 0.0, modeAmt = 0.0;
    int mode = 0;
    float seed = 0.0;
    float hp = 1.0, posture = 0.0, deadAmt = 0.0;

    if (valid) {
        vec3 s = slot(0);
        if (s.x < 1.0) {
            float k = (1.0 - s.x);
            shakeAmt = s.y * k * k;
            seed = s.z;
        }
        s = slot(1);
        if (s.x < 1.0) zoomAmt = s.y * sin(min(s.x * 1.3, 1.0) * PI);
        s = slot(2);
        if (s.x < 1.0) chromaAmt = s.y * (1.0 - s.x);
        s = slot(3);
        if (s.x < 1.0) {
            flashAmt = s.y * (1.0 - s.x) * (1.0 - s.x);
            int c = int(s.z);
            flashCol = c == 1 ? vec3(0.75, 0.04, 0.05) : c == 2 ? vec3(1.0, 0.82, 0.35) : c == 3 ? vec3(0.0) : vec3(1.0);
        }
        s = slot(4);
        if (s.x < 1.0) impactAmt = s.y;
        s = slot(5);
        if (s.x < 1.0) {
            modeAmt = smoothstep(0.0, 0.12, s.x) * (1.0 - smoothstep(0.78, 1.0, s.x));
            mode = int(s.z);
        }
        vec3 v = texelFetch(InSampler, ivec2(6, 0), 0).rgb;
        hp = v.r;
        posture = v.g;
        deadAmt = v.b;
    }

    // 흔들림과 작은 기울기
    if (shakeAmt > 0.001) {
        float t = now();
        vec2 off = vec2(sin(t * 3.7 + seed) + sin(t * 7.9 + seed * 2.1), cos(t * 4.3 + seed * 1.7) + cos(t * 8.7 + seed)) * 0.5;
        float roll = sin(t * 2.9 + seed * 3.0) * shakeAmt * 0.035;
        float z = 1.0 + shakeAmt * 0.05;
        vec2 p = centered * vec2(aspect, 1.0);
        p = mat2(cos(roll), -sin(roll), sin(roll), cos(roll)) * p;
        p /= vec2(aspect, 1.0);
        uv = 0.5 + p / z + off * shakeAmt * 0.018;
        centered = uv - 0.5;
    }

    vec3 col;
    if (zoomAmt > 0.002) {
        // 방사형 흐림
        vec3 acc = vec3(0.0);
        float strength = zoomAmt * 0.11;
        for (int i = 0; i < 10; i++) {
            float f = float(i) / 9.0;
            acc += scene(0.5 + centered * (1.0 - strength * f));
        }
        col = acc / 10.0;
    } else {
        col = scene(uv);
    }

    if (chromaAmt > 0.002) {
        vec2 dir = centered * chromaAmt * 0.022;
        col.r = scene(uv + dir).r;
        col.b = scene(uv - dir).b;
    }

    // 데이터 픽셀 숨기기
    if (px.y < 1 && px.x < 8) {
        col = texelFetch(InSampler, ivec2(px.x, 2), 0).rgb;
    }

    // 블룸
    vec3 bloom = texture(BloomSampler, uv).rgb;
    col += bloom * 0.62;

    // 수묵 전환
    if (modeAmt > 0.001) {
        vec3 base = col;
        if (mode == 1) {
            vec2 e = 1.2 / OutSize;
            float lc = luma(scene(uv));
            float gx = luma(scene(uv + vec2(e.x, 0.0))) - luma(scene(uv - vec2(e.x, 0.0)));
            float gy = luma(scene(uv + vec2(0.0, e.y))) - luma(scene(uv - vec2(0.0, e.y)));
            float edge = clamp(length(vec2(gx, gy)) * 3.4, 0.0, 1.0);
            float paperN = fbm(uv * vec2(aspect, 1.0) * 90.0) * 0.08;
            float ink = smoothstep(0.08, 0.78, lc);
            vec3 paper = vec3(0.93, 0.90, 0.82) - paperN;
            vec3 tone = mix(vec3(0.06, 0.06, 0.08), paper, ink);
            tone = mix(tone, vec3(0.03), edge * 0.9);
            base = tone;
        } else if (mode == 2) {
            float l = luma(col);
            base = vec3(l * 1.25, l * 0.25, l * 0.22);
        } else if (mode == 3) {
            float l = luma(col);
            base = mix(vec3(l), col * vec3(0.6, 0.85, 1.25), 0.35);
        } else if (mode == 4) {
            float l = luma(col);
            base = mix(vec3(l) * vec3(0.5, 0.45, 0.9), col * vec3(0.45, 0.42, 0.85), 0.5);
        }
        col = mix(col, base, modeAmt);
    }

    // 임팩트 프레임: 밝기만 남긴 흑백 반전
    if (impactAmt > 0.001) {
        float l = luma(col);
        float hard = smoothstep(0.42, 0.58, l);
        vec3 frame = vec3(1.0 - hard);
        col = mix(col, frame, impactAmt);
    }

    // 색보정: 어두운 곳은 차갑게, 밝은 곳은 따뜻하게, 약한 S곡선
    float L = luma(col);
    col *= mix(vec3(0.93, 0.97, 1.08), vec3(1.05, 1.0, 0.93), smoothstep(0.1, 0.85, L));
    vec3 sc = clamp(col, 0.0, 1.0);
    vec3 s2 = sc * sc * (3.0 - 2.0 * sc);
    col = mix(col, s2, 0.22);
    col = mix(vec3(luma(col)), col, 1.12);

    // 비네트
    vec2 q = (texCoord - 0.5) * vec2(aspect / 1.78, 1.0);
    float r = length(q);
    col *= 1.0 - smoothstep(0.42, 0.95, r) * 0.34;

    // 체력이 낮으면 가장자리에서 핏빛 먹이 번진다.
    if (valid && hp < 0.45) {
        float danger = (0.45 - hp) / 0.45;
        float pulse = 0.82 + 0.18 * sin(now() * 0.32);
        float n = fbm(q * 5.0 + vec2(0.0, now() * 0.012));
        float m = smoothstep(0.72 - danger * 0.44, 0.98 - danger * 0.2, r + n * 0.32) * pulse;
        col = mix(col, vec3(0.26, 0.015, 0.03) * (0.5 + n), m * (0.45 + danger * 0.5));
    }

    // 쓰러지면 색이 빠진다.
    if (deadAmt > 0.5) {
        float l = luma(col);
        col = mix(col, vec3(l) * vec3(0.92, 0.88, 0.84), 0.92) * 0.82;
    }

    // 번쩍임
    if (flashAmt > 0.001) {
        col = mix(col, flashCol, flashAmt * 0.85);
    }

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
