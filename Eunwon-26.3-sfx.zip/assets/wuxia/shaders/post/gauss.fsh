#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BlurConfig {
    vec2 Dir;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 px = Dir / InSize;
    vec3 c = texture(InSampler, texCoord).rgb * 0.227;
    c += (texture(InSampler, texCoord + px * 1.385).rgb + texture(InSampler, texCoord - px * 1.385).rgb) * 0.316;
    c += (texture(InSampler, texCoord + px * 3.231).rgb + texture(InSampler, texCoord - px * 3.231).rgb) * 0.0703;
    fragColor = vec4(c, 1.0);
}
